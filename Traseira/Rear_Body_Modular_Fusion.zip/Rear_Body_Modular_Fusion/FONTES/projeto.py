from pathlib import Path
import numpy as np,trimesh,manifold3d as mf,json,itertools,sys
R=Path(__file__).resolve().parent;O=R/'pacote';(O/'STL').mkdir(parents=True,exist_ok=True);(R/'estado').mkdir(exist_ok=True)
def mesh(s):
 a=s.to_mesh64();return trimesh.Trimesh(np.array(a.vert_properties[:,:3]),np.array(a.tri_verts),process=True)
def solid(m):return mf.Manifold(mf.Mesh64(np.array(m.vertices,dtype=np.float64),np.array(m.faces,dtype=np.uint64)))
def box(a,b):return mf.Manifold.cube(np.array(b)-a).translate(a)
def clean(s):
 cs=[c for c in s.decompose() if c.volume()>1.]
 return mf.Manifold.batch_boolean(cs,mf.OpType.Add)
def save(name,s):
 a=s.to_mesh64();np.savez(R/'estado'/(name+'.npz'),v=a.vert_properties[:,:3],f=a.tri_verts)
def ascii_stl(m,path):
 with path.open('w') as f:
  f.write('solid rear_body\n')
  for normal,tri in zip(m.face_normals,m.triangles):
   f.write('facet normal '+' '.join(format(float(x),'.17g') for x in normal)+'\nouter loop\n')
   for p in tri:f.write('vertex '+' '.join(format(float(x),'.17g') for x in p)+'\n')
   f.write('endloop\nendfacet\n')
  f.write('endsolid rear_body\n')
base=trimesh.load_mesh(R/'base_reparada.stl');s=solid(base).set_tolerance(.001).simplify(.06)
print('BASE',s.status(),s.num_tri(),s.volume(),flush=True)
# Curva traseira da tampa, interpretada das linhas existentes.
y=np.linspace(-72,72,81);back=-159+6*(abs(y)/72)**2
poly=[[-260,-72]]+[[float(x),float(yy)] for x,yy in zip(back,y)]+[[-260,72]]
mask=mf.CrossSection([np.array(poly)]).extrude(160)^box([-270,-110,0],[0,110,170])
parts={'01_tampa_porta_malas':s^mask};rest=s-mask
# Paineis traseiros abaixo do encontro com as colunas.
rearhalf,frontside=rest.split_by_plane([-1,0,-.08],51.4/np.sqrt(1+.08**2))
for sign,name in [(1,'02_paralama_traseiro_Ypositivo'),(-1,'03_paralama_traseiro_Ynegativo')]:
 cut=box([-260,72 if sign>0 else -115,0],[0,115 if sign>0 else -72,94.])
 parts[name]=rearhalf^cut;rearhalf=rearhalf-cut
rest=rearhalf+frontside
for sign,name in [(1,'04_trecho_lateral_Ypositivo'),(-1,'05_trecho_lateral_Ynegativo')]:
 side=box([-80,70 if sign>0 else -115,0],[0,115 if sign>0 else -70,85.5])
 side=side^frontside
 parts[name]=side;rest=rest-side
mask=box([-147,-56,91.5],[-112,56,120])
parts['06_painel_vidro_traseiro']=rest^mask;rest=rest-mask
mask=box([-112,-59,105],[0,59,145])
parts['07_teto_com_antena']=rest^mask;rest=rest-mask
parts['08_moldura_colunas_traseiras']=rest
for n,p in list(parts.items()):
 p=clean(p);parts[n]=p
 print('CORTE',n,len(p.decompose()),p.volume(),p.num_tri(),flush=True)
 save('corte_'+n,p)

log=[];names=list(parts)
def inside_z(x,y):
 hits,_,_=base.ray.intersects_location([[x,y,180]],[[0,0,-1]],multiple_hits=True)
 z=np.sort(hits[:,2]);return float(z[-2]) if len(z)>=2 else None

def inside_y(x,z,sign):
 hits,_,_=base.ray.intersects_location([[x,0,z]],[[0,sign,0]],multiple_hits=True)
 y=sign*hits[:,1];y=y[y>0];return sign*float(min(y)) if len(y) else None

def cylinder_link(start,end,r=1.8):
 start=np.array(start,dtype=float);d=np.array(end)-start;length=np.linalg.norm(d);axis=d/length
 other=np.array([0.,0.,1.]) if abs(axis[2])<.9 else np.array([0.,1.,0.]);vx=np.cross(other,axis);vx/=np.linalg.norm(vx);vy=np.cross(axis,vx)
 return mf.Manifold.cylinder(length,r,r,32).transform(np.column_stack([vx,vy,axis,start]))

def attach(body,addition,point):
 if len(clean(body+addition).decompose())==1:return clean(body+addition)
 bm=mesh(body);closest,dist,idx=trimesh.proximity.closest_point(bm,[point]);q=closest[0]-bm.face_normals[idx[0]]*.7
 return clean(body+addition+cylinder_link(point,q))

def tab(a,b,p,n,u,label,depth=3.):
 n=np.array(n,dtype=float);n/=np.linalg.norm(n);u=np.array(u,dtype=float);u-=n*np.dot(n,u);u/=np.linalg.norm(u);t=np.cross(u,n);mat=np.column_stack([n,t,u]);p=np.array(p,dtype=float)+u*depth
 def B(lo,hi):return box(lo,hi).transform(np.column_stack([mat,p]))
 root=B([-6,-4,-.8],[-.1,4,3]);tongue=B([-1,-1.5,.5],[4.5,1.5,2.3]);receiver=B([.3,-4,-.8],[7,4,3.3]);cavity=B([-.2,-1.8,.2],[4.8,1.8,2.6])
 pa=attach(parts[a],root+tongue,p+mat@[-3.,0,1.]);pb=clean(attach(parts[b],receiver,p+mat@[4.,0,1.])-cavity-pa)
 parts[a]=pa;parts[b]=pb;log.append(dict(nome=label,tipo='lingueta_interna',a=a,b=b,ponto=p.tolist(),folga_lado_mm=.3,solidos_a=len(pa.decompose()),solidos_b=len(pb.decompose())))
 print('GUIA',label,len(pa.decompose()),len(pb.decompose()),flush=True)

for sign,fi,di in [(1,1,3),(-1,2,4)]:
 # Junta inclinada entre o painel com arco e o trecho lateral anterior.
 for z in [30.,60.]:
  x=-51.4-.08*z;y=inside_y(x,z,sign)
  tab(names[fi],names[di],[x,y,z],[1,0,.08],[0,-sign,0],f'paralama_lateral_{sign}_{z}')
 # Ombro entre lateral anterior e estrutura superior.
 x=-24.;z=85.5;y=inside_y(x,z,sign)
 tab(names[di],names[7],[x,y,z],[0,0,1],[0,-sign,0],f'lateral_coluna_{sign}')
 # Encontro horizontal do painel traseiro com a coluna C.
 x=-128.;z=94.;y=inside_y(x,z,sign)
 tab(names[fi],names[7],[x,y,z],[0,0,1],[0,-sign,0],f'paralama_coluna_{sign}',depth=10.)
 # Vidro traseiro e sua moldura lateral.
 x=-129.;y=sign*56.;z=inside_z(x,y)
 tab(names[5],names[7],[x,y,z],[0,sign,0],[1,0,-1],f'vidro_moldura_{sign}')
 # Teto e colunas, guias laterais.
 x=-65.;y=sign*59.;z=inside_z(x,y)
 tab(names[6],names[7],[x,y,z],[0,sign,0],[0,0,-1],f'teto_coluna_{sign}')
 # Tampa removivel: dois pinos verticais por lado, flange no painel traseiro.
 for x in [-207.,-179.]:
  yc=sign*66.;zi=inside_z(x,yc)
  inner=[inside_z(x,sign*q) for q in [74,76,78]];zf=zi-1.2
  lo,hi=sorted([sign*61.,sign*80.]);shelf=box([x-4,lo,zf-2.8],[x+4,hi,zf])
  lo2,hi2=sorted([sign*73.,sign*80.]);anchor=box([x-4,lo2,zf-2.8],[x+4,hi2,zf+1.0])
  hole=mf.Manifold.cylinder(16,2.3,2.3,48).translate([x,yc,zf-5]);support=(shelf+anchor)-hole
  peg=mf.Manifold.cylinder(zi+.65-(zf-2.4),2.,2.,48).translate([x,yc,zf-2.4])
  parts[names[0]]=clean(parts[names[0]]+peg);parts[names[fi]]=attach(parts[names[fi]],support,[x,sign*76.,zf-1.])
  log.append(dict(tipo='pino_tampa',ponto=[x,yc,zf],diametro_pino_mm=4.,diametro_furo_mm=4.6))
  print('PINO',x,yc,len(parts[names[0]].decompose()),len(parts[names[fi]].decompose()),flush=True)

# Verificacao global das guias; recortes no receptor preservam as pecas moveis.
rep=[]
for na,nb in itertools.combinations(parts,2):
 a,b=parts[na],parts[nb]
 v=max(abs((a^b).volume()),abs((b^a).volume()))
 if v>.02:
  print('AJUSTE',na,nb,v,flush=True);parts[nb]=clean(b-a)
for n,p in list(parts.items()):
 assert p.status()==mf.Error.NoError
 m=mesh(p)
 if not m.is_volume:
  reset=p.to_mesh64();p=mf.Manifold(mf.Mesh64(np.array(reset.vert_properties[:,:3],dtype=np.float64,order='C'),np.array(reset.tri_verts,dtype=np.uint64,order='C')));m=mesh(p)
 for tolerance in [.00001,.0001,.001,.002]:
  if m.is_volume:break
  p=clean(p.simplify(tolerance));m=mesh(p)
 assert m.is_volume and len(p.decompose())==1,(n,'invalid final mesh')
 parts[n]=p
for n,p in parts.items():
 m=mesh(p);print('FINAL',n,len(p.decompose()),p.num_tri(),p.volume(),flush=True)
 save(n,p);ascii_stl(m,O/'STL'/(n+'.stl'))
 rep.append(dict(nome=n,solidos=len(p.decompose()),faces=len(m.faces),volume_mm3=p.volume(),malha_fechada=m.is_watertight,orientacao_consistente=m.is_winding_consistent,limites_mm=m.bounds.tolist()))
(O/'encaixes.json').write_text(json.dumps(log,indent=2))
(O/'validacao_inicial.json').write_text(json.dumps(rep,indent=2))
