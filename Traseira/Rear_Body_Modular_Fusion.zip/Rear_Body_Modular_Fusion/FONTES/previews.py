from pathlib import Path
import numpy as np,trimesh,manifold3d as mf
from render_vtk import render
import vtk
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray,vtk_to_numpy

def render_mesh(m):
 poly=vtk.vtkPolyData();pts=vtk.vtkPoints();pts.SetData(numpy_to_vtk(np.asarray(m.vertices),deep=True));poly.SetPoints(pts)
 cells=vtk.vtkCellArray();packed=np.column_stack((np.full(len(m.faces),3,dtype=np.int64),m.faces)).ravel();cells.SetCells(len(m.faces),numpy_to_vtkIdTypeArray(packed,deep=True));poly.SetPolys(cells)
 normals=vtk.vtkPolyDataNormals();normals.SetInputData(poly);normals.ConsistencyOn();normals.AutoOrientNormalsOn();normals.SplittingOn();normals.SetFeatureAngle(35);normals.ComputePointNormalsOn();normals.Update()
 a=normals.GetOutput();v=vtk_to_numpy(a.GetPoints().GetData());n=vtk_to_numpy(a.GetPointData().GetNormals());f=vtk_to_numpy(a.GetPolys().GetData()).reshape(-1,4)[:,1:];return v,n,np.ascontiguousarray(f,dtype=np.int32)

R=Path(__file__).resolve().parent;O=R/'pacote';stage='corte_' if not (R/'estado/01_tampa_porta_malas.npz').exists() else ''
colors=[(.78,.25,.18),(.25,.5,.8),(.25,.5,.8),(.32,.68,.4),(.32,.68,.4),(.45,.7,.85),(.9,.65,.22),(.6,.45,.7)]
offsets=[(-30,0,50),(-10,40,-5),(-10,-40,-5),(25,40,-15),(25,-40,-15),(0,0,35),(20,0,65),(15,0,5)]
parts=[];meshes={};ex={}
paths=sorted((R/'estado').glob(stage+'0*.npz'))
for p,col,off in zip(paths,colors,offsets):
 a=np.load(p);m=trimesh.Trimesh(a['v'],a['f'],process=True);n=p.stem.removeprefix('corte_');parts.append(dict(name=n,color=col))
 v,norm,f=render_mesh(m);meshes[n]=(v,norm,f);ex[n]=(v+off,norm,f)
for label,ms,el in [('MONTADO',meshes,25),('EXPLODIDO',ex,25),('ENCAIXES_INTERNOS',meshes,-30)]:render(parts,O/(label+'.png'),meshes=ms,azimuth=35,elevation=el,size=(1600,1100))
print('PREVIAS',len(parts),stage,flush=True)
