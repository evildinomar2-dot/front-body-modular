from pathlib import Path
import numpy as np,trimesh,cadquery as cq,json,sys
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeVertex,BRepBuilderAPI_MakeEdge,BRepBuilderAPI_MakeWire,BRepBuilderAPI_MakeFace
from OCP.BRep import BRep_Builder
from OCP.TopoDS import TopoDS,TopoDS_Shell
from OCP.gp import gp_Pnt
R=Path(__file__).resolve().parent;O=R/'pacote';(O/'STEP').mkdir(exist_ok=True)
colors=[(.78,.25,.18),(.25,.5,.8),(.25,.5,.8),(.32,.68,.4),(.32,.68,.4),(.45,.7,.85),(.9,.65,.22),(.6,.45,.7)]
assembly=cq.Assembly(name='REAR_BODY_V1_MODULAR');records=[]
for p,col in zip(sorted((R/'estado').glob('0*.npz')),colors):
 data=np.load(p);m=trimesh.Trimesh(data['v'],data['f'],process=True);v=m.vertices;f=m.faces
 assert m.is_volume and len(m.split())==1,(p.stem,'invalid mesh')
 if ('--reuse-first-seven' in sys.argv and not p.stem.startswith('08')) or ('--reuse-unchanged-five' in sys.argv and p.stem[:2] in ['01','04','05','06']):
  body=cq.importers.importStep(str(O/'STEP'/(p.stem+'.step'))).val()
  assert body.isValid() and len(body.Solids())==1 and abs(body.Volume()-m.volume)<max(.02,abs(m.volume)*1e-6)
  assembly.add(body,name=p.stem,color=cq.Color(*col));records.append(dict(nome=p.stem,solidos=1,valido=True,reimportado=True,faces_brep=len(body.Faces()),volume_mm3=body.Volume(),diferenca_volume_stl_mm3=abs(body.Volume()-m.volume)))
  print('STEP PRESERVADO',p.stem,flush=True)
  continue
 print('CAD',p.stem,len(f),flush=True)
 vertices=[BRepBuilderAPI_MakeVertex(gp_Pnt(*map(float,point))).Vertex() for point in v];edges={};builder=BRep_Builder();shell=TopoDS_Shell();builder.MakeShell(shell)
 for tri in f:
  wire=BRepBuilderAPI_MakeWire()
  for start,end in zip(tri,np.roll(tri,-1)):
   key=tuple(sorted([int(start),int(end)]))
   if key not in edges:edges[key]=BRepBuilderAPI_MakeEdge(vertices[key[0]],vertices[key[1]]).Edge()
   wire.Add(edges[key] if start<end else TopoDS.Edge_s(edges[key].Reversed()))
  face=BRepBuilderAPI_MakeFace(wire.Wire()).Face()
  builder.Add(shell,face)
 shell.Closed(True);raw=cq.Solid.makeSolid(cq.Shell(shell));body=raw
 for label,candidate in [('raw',raw),('fixed',raw.fix()),('clean',raw.clean().fix())]:
  print('CANDIDATE',p.stem,label,candidate.ShapeType(),candidate.isValid(),len(candidate.Solids()),flush=True)
  if candidate.isValid() and len(candidate.Solids())==1:
   body=candidate;break
 print('NATIVE',body.ShapeType(),body.isValid(),len(body.Solids()),body.Volume(),flush=True)
 if not body.isValid():
  from OCP.BRepCheck import BRepCheck_Analyzer
  an=BRepCheck_Analyzer(body.wrapped)
  print([(a.ShapeType(),a.Center().toTuple(),[str(x) for x in an.Result(a.wrapped).Status()]) for a in body.Faces()+body.Shells()+[body] if any('NoError' not in str(x) for x in an.Result(a.wrapped).Status())],flush=True)
 assert body.isValid() and len(body.Solids())==1
 assert abs(body.Volume()-m.volume)<max(.02,abs(m.volume)*1e-6)
 dest=O/'STEP'/(p.stem+'.step');cq.exporters.export(body,str(dest));q=cq.importers.importStep(str(dest)).val()
 assert q.isValid() and len(q.Solids())==1,(p.stem,'invalid reimport')
 assert abs(q.Volume()-m.volume)<max(.02,abs(m.volume)*1e-6)
 assembly.add(body,name=p.stem,color=cq.Color(*col));records.append(dict(nome=p.stem,solidos=1,valido=True,reimportado=True,faces_brep=len(body.Faces()),volume_mm3=body.Volume(),diferenca_volume_stl_mm3=abs(body.Volume()-m.volume)))
 print('STEP OK',p.stem,flush=True)
(O/'validacao_step.json').write_text(json.dumps(records,indent=2))
assembly.export(str(O/'MONTAGEM_TRASEIRA_MODULAR.step'));print('MONTAGEM EXPORTADA',flush=True)
q=cq.importers.importStep(str(O/'MONTAGEM_TRASEIRA_MODULAR.step')).val();assert q.isValid() and len(q.Solids())==8
(O/'validacao_montagem_step.json').write_text(json.dumps(dict(solidos=8,valido=True,reimportado=True),indent=2));print('MONTAGEM REIMPORTADA:8 SOLIDOS VALIDOS',flush=True)
