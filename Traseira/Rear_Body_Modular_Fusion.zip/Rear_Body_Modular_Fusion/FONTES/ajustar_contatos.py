from pathlib import Path
import numpy as np,trimesh,manifold3d as mf,json,itertools
R=Path(__file__).resolve().parent;O=R/'pacote';parts={};changes=[]
def mesh(s):
 a=s.to_mesh64();return trimesh.Trimesh(a.vert_properties[:,:3],a.tri_verts,process=True)
for p in sorted((R/'estado').glob('0*.npz')):
 a=np.load(p);parts[p.stem]=mf.Manifold(mf.Mesh64(np.asarray(a['v'],dtype=np.float64),np.asarray(a['f'],dtype=np.uint64)))
for na,nb in itertools.combinations(parts,2):
 a,b=parts[na],parts[nb];v=max(abs((a^b).volume()),abs((b^a).volume()))
 if v>.02:
  print('CUT',na,nb,v,flush=True);parts[nb]=b-a;changes.append(dict(a=na,b=nb,volume_retirado_mm3=v))
for n,s in parts.items():
 q=mesh(s)
 if not q.is_volume:
  reset=s.to_mesh64();s=mf.Manifold(mf.Mesh64(np.array(reset.vert_properties[:,:3],dtype=np.float64,order='C'),np.array(reset.tri_verts,dtype=np.uint64,order='C')))
 for tolerance in [.00001,.0001,.001,.002,.005,.01]:
  if q.is_volume and len(s.decompose())==1:break
  s=s.simplify(tolerance);chunks=[c for c in s.decompose() if abs(c.volume())>1.];s=mf.Manifold.batch_boolean(chunks,mf.OpType.Add);q=mesh(s)
  print('REPAIR',n,tolerance,q.is_volume,len(s.decompose()),flush=True)
 assert q.is_volume and len(s.decompose())==1,(n,'invalid mesh')
 a=s.to_mesh64();np.savez(R/'estado'/(n+'.npz'),v=a.vert_properties[:,:3],f=a.tri_verts)
 out=O/'STL'/(n+'.stl')
 with out.open('w') as f:
  f.write('solid rear_body\n')
  for normal,tri in zip(q.face_normals,q.triangles):
   f.write('facet normal '+' '.join(format(float(x),'.17g') for x in normal)+'\nouter loop\n')
   for point in tri:f.write('vertex '+' '.join(format(float(x),'.17g') for x in point)+'\n')
   f.write('endloop\nendfacet\n')
  f.write('endsolid rear_body\n')
(O/'ajustes_contatos.json').write_text(json.dumps(changes,indent=2))
