from pathlib import Path
import numpy as np,trimesh,manifold3d as mf,json,itertools
R=Path(__file__).resolve().parent;O=R/'pacote';parts=[];records=[]
for p in sorted((O/'STL').glob('*.stl')):
 m=trimesh.load_mesh(p);s=mf.Manifold(mf.Mesh64(np.asarray(m.vertices,dtype=np.float64),np.asarray(m.faces,dtype=np.uint64)))
 assert m.is_volume and s.status()==mf.Error.NoError and len(s.decompose())==1,(p.stem,'invalid')
 a=np.load(R/'estado'/(p.stem+'.npz'));assert np.allclose(m.bounds,np.array([a['v'].min(0),a['v'].max(0)]),atol=1e-8)
 print('STL',p.stem,'OK',flush=True);parts.append((p.stem,s));records.append(dict(nome=p.stem,solidos=1,malha_fechada=True,orientacao_consistente=True,volume_mm3=m.volume,faces=len(m.faces),limites_mm=m.bounds.tolist()))
pairs=[]
for (na,a),(nb,b) in itertools.combinations(parts,2):
 v=max(abs((a^b).volume()),abs((b^a).volume()));pairs.append(dict(a=na,b=nb,volume_interferencia_mm3=v));print('PAIR',na[:2],nb[:2],v,flush=True);assert v<.02,(na,nb,v)
lift=[]
for z in [.5,2.,5.,10.,20.,40.]:
 p=parts[0][1].translate([0,0,z]);vals=[dict(peca=n,volume_mm3=max(abs((p^s).volume()),abs((s^p).volume()))) for n,s in parts[1:]]
 lift.append(dict(elevacao_mm=z,pares=vals));maximum=max(a['volume_mm3'] for a in vals);print('TAMPA',z,maximum,flush=True);assert maximum<.02
(O/'validacao.json').write_text(json.dumps(dict(unidade_assumida='mm',escala=1,pecas=records,pares=pairs,limiar_interferencia_mm3=.02,retirada_tampa=lift,teste_retirada='posicoes discretas; nao e varredura continua',testado_fisicamente=False,testado_no_fusion=False),indent=2))
print('8 STL + 28 PARES + RETIRADA TAMPA:OK',flush=True)
