from pathlib import Path
import numpy as np,trimesh,json
R=Path(__file__).resolve().parent;p=R/'estado/08_moldura_colunas_traseiras.npz';a=np.load(p);m=trimesh.Trimesh(a['v'],a['f'],process=True);v=m.vertices;f=m.faces.copy();before=m.volume;flips=0

def height(tri):
 pts=v[tri];area2=np.linalg.norm(np.cross(pts[1]-pts[0],pts[2]-pts[0]));long=max(np.linalg.norm(pts[i]-pts[j]) for i,j in [(0,1),(1,2),(2,0)])
 return area2/max(long,1e-30)

for cycle in range(5):
 edgefaces={}
 for i,tri in enumerate(f):
  for u,w in zip(tri,np.roll(tri,-1)):edgefaces.setdefault(tuple(sorted([int(u),int(w)])),[]).append(i)
 used=set();count=0
 candidates=sorted([(height(tri),i) for i,tri in enumerate(f) if height(tri)<.005])
 for oldh,i in candidates:
  if i in used:continue
  tri=f[i];normal=np.cross(v[tri[1]]-v[tri[0]],v[tri[2]]-v[tri[0]]);nl=np.linalg.norm(normal)
  if nl<1e-20:continue
  normal/=nl
  for aa,bb in sorted(zip(tri,np.roll(tri,-1)),key=lambda e:-np.linalg.norm(v[e[0]]-v[e[1]])):
   u,w=int(aa),int(bb);neigh=edgefaces[tuple(sorted([u,w]))]
   if len(neigh)!=2:continue
   j=next(k for k in neigh if k!=i)
   if j in used:continue
   c=next(int(k) for k in tri if k not in [u,w]);d=next(int(k) for k in f[j] if k not in [u,w])
   if c==d or tuple(sorted([c,d])) in edgefaces:continue
   if abs(np.dot(v[d]-v[tri[0]],normal))>1e-4:continue
   t1=np.array([c,d,u]);t2=np.array([d,c,w])
   for t in [t1,t2]:
    if np.dot(np.cross(v[t[1]]-v[t[0]],v[t[2]]-v[t[0]]),normal)<0:t[1],t[2]=t[2],t[1]
   def area(t):return np.linalg.norm(np.cross(v[t[1]]-v[t[0]],v[t[2]]-v[t[0]]))*.5
   oldarea=area(tri)+area(f[j]);newarea=area(t1)+area(t2)
   if abs(newarea-oldarea)>max(1e-8,oldarea*1e-8):continue
   if min(height(t1),height(t2))<=min(oldh,height(f[j]))*1.5:continue
   f[i]=t1;f[j]=t2;used.update([i,j]);count+=1;break
 flips+=count;print('FLIPS',cycle,count,flush=True)
 if not count:break
q=trimesh.Trimesh(v,f,process=True);assert q.is_volume and abs(q.volume-before)<.02
np.savez(p,v=q.vertices,f=q.faces)
out=R/'pacote/STL/08_moldura_colunas_traseiras.stl'
with out.open('w') as stream:
 stream.write('solid moldura\n')
 for normal,tri in zip(q.face_normals,q.triangles):
  stream.write('facet normal '+' '.join(format(float(x),'.17g') for x in normal)+'\nouter loop\n')
  for point in tri:stream.write('vertex '+' '.join(format(float(x),'.17g') for x in point)+'\n')
  stream.write('endloop\nendfacet\n')
 stream.write('endsolid moldura\n')
(R/'pacote/triangulacao.json').write_text(json.dumps(dict(trocas_diagonal_coplanares=flips,diferenca_volume_mm3=q.volume-before,tolerancia_coplanar_mm=1e-4),indent=2))
