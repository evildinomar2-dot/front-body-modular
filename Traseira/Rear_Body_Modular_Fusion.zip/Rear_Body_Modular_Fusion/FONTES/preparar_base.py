from pathlib import Path
import numpy as np,trimesh
R=Path(__file__).resolve().parent
m=trimesh.load_mesh(R.parent/'ORIGINAL/Rear_Body_V1.stl')
parts=m.split(only_watertight=False);m=max(parts,key=lambda a:abs(a.volume))
assert m.is_volume
transform=np.eye(4);transform[:3,:3]=[[0,0,-1],[1,0,0],[0,-1,0]];m.apply_transform(transform);m.export(R/'base_reparada.stl')
print('Base principal fechada, sem reescala; dois triangulos soltos nao incluidos.')
