# Reprodução do pacote traseiro

Python 3.12, compilador C `cc` e bibliotecas em requirements-ambiente.txt. Instale num ambiente virtual e execute na pasta FONTES, numa cópia de trabalho:

```
python preparar_base.py
python projeto.py
python ajustar_contatos.py
python melhorar_triangulacao.py
python validar.py
python exportar_cad.py
python previews.py
```

Use um shell com `set -e` se colocar os comandos num script, para interromper ao primeiro erro. Os resultados da reconstrução são criados em FONTES/pacote/; não sobrescrevem diretamente os arquivos finais na pasta superior do ZIP. Os estados intermediários ficam em FONTES/estado/. A entrada é ../ORIGINAL/Rear_Body_V1.stl.

Os cortes e os pontos de encaixe estão em projeto.py. O ajuste de contatos verifica ambos os sentidos da interseção. melhorar_triangulacao.py melhora diagonais de triângulos muito estreitos em áreas quase planas, com desvio local permitido de 0,0001 mm e verificação de diferença de volume abaixo de 0,02 mm³. Os fragmentos soltos de corte menores que 1 mm³ podem ser eliminados. A geração de F3D exige o próprio Autodesk Fusion, via pasta Fusion/GerarF3D.

Os scripts foram usados e validados na preparação deste pacote. Os caminhos relativos do pacote foram conferidos; a reprodução completa a partir desta pasta empacotada não foi repetida num ambiente novo. Os comandos de reutilização em exportar_cad.py foram usados apenas para peças já validadas e sem alteração durante as correções; para uma reconstrução nova, execute sem opções de reutilização.
