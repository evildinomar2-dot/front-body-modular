from pathlib import Path
import cadquery as cq,numpy as np,json,itertools
R=Path(__file__).resolve().parent;D=R/'ESTUDO_01/COMPONENTES_LOGICOS';O=R/'ESTUDO_01/DIVISAO_CABINE';O.mkdir(exist_ok=True)
def box(lo,hi):return cq.Solid.makeBox(*[hi[i]-lo[i] for i in range(3)],cq.Vector(*lo))
A=cq.Assembly(name='ESTUDO_DIVISAO_CABINE_220MM');records=[]
def add(name,s,color):
 for i,p in enumerate(s.Solids()):
  if p.Volume()<1:continue
  assert p.isValid(),name
  label=name+(f'_{i+1}' if len(s.Solids())>1 else '');b=p.BoundingBox();dim=np.array([b.xlen,b.ylen,b.zlen])
  candidates=[]
  for perm in itertools.permutations([0,1,2]):
   d=dim[list(perm)]
   if np.all(d<=np.array([218,218,248])):candidates.append((float(d[2]),perm,d))
  assert candidates,(label,dim)
  _,perm,d=min(candidates,key=lambda a:a[0]);cq.exporters.export(p,str(O/(label+'.step')));A.add(p,name=label,color=cq.Color(*color))
  records.append(dict(nome=label,solido_valido=True,dimensoes_xyz_mm=dim.tolist(),ordem_eixos_impressao_sugerida=list(perm),dimensoes_orientadas_mm=d.tolist(),cabe_em_envelope_218_218_248=True,encaixes_definitivos=False))

orange=(.94,.22,.035)
for filename,tag,zs,xs in [('01_teto.step','teto',[(0,500)],[(0,190),(190,400)]),('02_painel_traseiro_cabine.step','traseiro',[(0,260),(260,418)],[(0,400)]),('03_frente_e_colunas_A.step','frente',[(0,250),(250,418)],[(-100,400)])]:
 s=cq.importers.importStep(str(D/filename)).val()
 for zi,(z0,z1) in enumerate(zs):
  for xi,(x0,x1) in enumerate(xs):
   for sign,(y0,y1) in enumerate([(-250,0),(0,250)]):add(f'{tag}_{zi+1}_{xi+1}_{sign+1}',s.intersect(box([x0,y0,z0],[x1,y1,z1])),orange)
for sign in ['Ypositivo','Ynegativo']:
 s=cq.importers.importStep(str(D/('04_lateral_cabine_'+sign+'.step' if sign=='Ypositivo' else '05_lateral_cabine_'+sign+'.step'))).val()
 for xi,(x0,x1) in enumerate([(60,110),(110,320)]):
  for zi,(z0,z1) in enumerate([(0,235),(235,418)]):add(f'lateral_{sign}_{xi+1}_{zi+1}',s.intersect(box([x0,-250,z0],[x1,250,z1])),orange)
A.export(str(R/'ESTUDO_01/ESTUDO_DIVISAO_CABINE.step'));(R/'ESTUDO_01/divisao_cabine.json').write_text(json.dumps(dict(status='DIVISAO_PRELIMINAR_SEM_ENCAIXES_FINAIS',impressora_mm=[220,220,250],envelope_validado_mm=[218,218,248],pecas=records),indent=2));print('CABINE',len(records),'paineis validos dentro do envelope da impressora',flush=True)
