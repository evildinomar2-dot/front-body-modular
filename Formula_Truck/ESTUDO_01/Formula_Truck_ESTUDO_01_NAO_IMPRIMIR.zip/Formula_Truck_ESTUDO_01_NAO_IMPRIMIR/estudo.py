from pathlib import Path
import cadquery as cq,numpy as np,json,sys
R=Path(__file__).resolve().parent;O=R/'ESTUDO_01';O.mkdir(exist_ok=True);P=json.loads((R/'parametros_estudo.json').read_text())
wall=P['parede_nominal'];parts=[];refs=[]
def box(lo,hi):return cq.Solid.makeBox(*[hi[i]-lo[i] for i in range(3)],cq.Vector(*lo))
def rounded_wire(front,rear,width,z,r):
 a,b=front,rear;c,d=-width/2,width/2
 return (cq.Workplane('XY',origin=(0,0,z)).moveTo(a+r,c).lineTo(b-r,c).radiusArc((b,c+r),-r).lineTo(b,d-r).radiusArc((b-r,d),-r).lineTo(a+r,d).radiusArc((a,d-r),-r).lineTo(a,c+r).radiusArc((a+r,c),-r).close().val())
def loft(profiles,r):return cq.Solid.makeLoft([rounded_wire(*p,r) for p in profiles],False)
def add(name,s,color,group='carroceria'):
 if s.Volume()<.01:return
 assert s.isValid(),name
 for i,body in enumerate(s.Solids()):
  if body.Volume()<.05:continue
  dest=parts if group=='carroceria' else refs
  dest.append(dict(name=name+(f'_{i+1}' if len(s.Solids())>1 else ''),shape=body,color=color))

orange=(.94,.22,.035);dark=(.10,.12,.14);silver=(.62,.67,.72);glass=(.23,.35,.42)
outer=loft([(24,344,376,100),(17,344,372,230),(49,327,358,410),(62,320,352,450)],15)
inner=loft([(27,341,370,97),(20,341,366,230),(52,324,352,410),(65,317,346,447)],12)
cab=outer.cut(inner);print('CAB SHELL',cab.isValid(),len(cab.Solids()),flush=True)
# Four-corner rounded windshield opening, through the front wall only.
frontmask=(cq.Workplane('YZ',origin=(-60,0,0)).polyline([(-150,257),(150,257),(144,402),(-144,402)]).close().extrude(180).edges('|X').fillet(10).val())
frontglass=cab.intersect(frontmask);cab=cab.cut(frontmask)
side=(cq.Workplane('XZ',origin=(0,230,0)).polyline([(81,248),(292,248),(289,395),(108,407),(81,382)]).close().extrude(95).edges('|Y').fillet(8).val())
sg1=cab.intersect(side);cab=cab.cut(side);sg2=cab.intersect(side.mirror('XZ'));cab=cab.cut(side.mirror('XZ'))
# Native grille openings, preserving a central mount for a separate circular badge.
for z,h,w in [(210,24,260),(158,32,242)]:
 for sign in [-1,1]:
  y0,y1=(39,w/2) if sign>0 else (-w/2,-39)
  cab=cab.cut(box([-70,y0,z-h/2],[115,y1,z+h/2]))
# Wheel clearance is provisional and intentionally larger than the guide tires.
ax=P['eixo_dianteiro_x_provisorio'];tz=P['diametro_pneu_referencia_provisorio']/2
wheelcut=cq.Solid.makeCylinder(130,480,cq.Vector(ax,-240,tz),cq.Vector(0,1,0));cab=cab.cut(wheelcut)
# Receiver holes for the separate emblem and mirror stems.
for angle in [90,210,330]:
 aa=np.radians(angle);yy=30.75*np.cos(aa);zz=184+30.75*np.sin(aa)
 cab=cab.cut(cq.Solid.makeCylinder(2.,24,cq.Vector(8,float(yy),float(zz)),cq.Vector(1,0,0)))
for sign in [-1,1]:cab=cab.cut(cq.Solid.makeCylinder(3.25,55,cq.Vector(40,sign*167,320),cq.Vector(0,sign,0)))
# Rear under-cab clearance for the chassis; exact mounts still need the actual frame.
cab=cab.cut(box([307,-155,0],[370,155,190]))

# Logical panels for the first visual study. Final print subdivisions/fasteners are pending.
roofmask=box([-100,-250,418],[400,250,500]);roof=cab.intersect(roofmask);cab=cab.cut(roofmask);add('01_teto',roof,orange)
backmask=box([310,-250,0],[390,250,418]);back=cab.intersect(backmask);cab=cab.cut(backmask);add('02_painel_traseiro_cabine',back,orange)
frontpanelmask=box([-100,-250,0],[70,250,418]);front=cab.intersect(frontpanelmask);cab=cab.cut(frontpanelmask);add('03_frente_e_colunas_A',front,orange)
add('04_lateral_cabine_Ypositivo',cab.intersect(box([60,0,0],[320,250,418])),orange)
add('05_lateral_cabine_Ynegativo',cab.intersect(box([60,-250,0],[320,0,418])),orange)
# Optional glazing volumes, shown only as visual references in this first study.
for name,s in [('vidro_lateral_positivo_referencia',sg1),('vidro_lateral_negativo_referencia',sg2)]:add(name,s,glass,'referencia')
add('vidro_frontal_referencia',frontglass.intersect(box([-100,-200,280],[150,200,377])),glass,'referencia')
add('faixa_superior_vidro_referencia',frontglass.intersect(box([-100,-200,377],[150,200,410])),(.9,.9,.87),'referencia')
add('faixa_inferior_vidro_referencia',frontglass.intersect(box([-100,-200,250],[150,200,280])),(.9,.9,.87),'referencia')

# Racing bumper shell; grille inlets are actual openings rather than painted areas.
bouter=loft([(-26,87,400,20),(-22,82,398,60),(0,78,388,96)],12)
binner=loft([(-22.5,110,393,17),(-18.5,110,391,60),(3.5,110,381,99)],9)
bumper=bouter.cut(binner).cut(wheelcut)
for y,w,z,h in [(0,145,48,34),(-139,45,47,35),(139,45,47,35)]:
 tool=(cq.Workplane('YZ',origin=(-80,y,z)).rect(w,h).extrude(210).edges('|X').fillet(7).val());bumper=bumper.cut(tool)
# Three native body sections, with internal joints still to be designed after printer dimensions.
for i,(y0,y1) in enumerate([(-210,-67),(-67,67),(67,210)],1):add(f'06_parachoque_secao_{i}',bumper.intersect(box([-60,y0,0],[120,y1,110])),orange)
lip=(cq.Workplane('XY',origin=(0,0,17)).polyline([(-31,-197),(60,-196),(79,-168),(80,168),(60,196),(-31,197)]).close().extrude(3).val())
for i,(y0,y1) in enumerate([(-210,-67),(-67,67),(67,210)],1):add(f'07_lamina_inferior_secao_{i}',lip.intersect(box([-60,y0,0],[120,y1,40])),orange)

def arch(cx,sign,rear=False):
 # Wheel-arch cover + outer lip, both genuine hollow geometry.
 start=165 if sign>0 else -197
 canopy=cq.Solid.makeCylinder(126,32,cq.Vector(cx,start,tz),cq.Vector(0,1,0)).cut(cq.Solid.makeCylinder(122,34,cq.Vector(cx,start-1,tz),cq.Vector(0,1,0)))
 lipstart=197 if sign>0 else -200
 edging=cq.Solid.makeCylinder(128,3,cq.Vector(cx,lipstart,tz),cq.Vector(0,1,0)).cut(cq.Solid.makeCylinder(118,5,cq.Vector(cx,lipstart-1,tz),cq.Vector(0,1,0)))
 return canopy.fuse(edging).intersect(box([cx-135,-210,35],[cx+135,210,245]))
for sign in [-1,1]:
 add(f'08_paralama_dianteiro_{sign}',arch(ax,sign),orange)
 rearax=P['eixo_traseiro_x_provisorio'];add(f'09_paralama_traseiro_{sign}',arch(rearax,sign,True),orange)
 # Side fairings; their length is provisional until the actual wheelbase is known.
 outline=[(285,25),(625,25),(651,58),(660,128),(622,151),(300,151),(281,123)]
 fair=(cq.Workplane('XZ',origin=(0,194 if sign>0 else -190,0)).polyline(outline).close().extrude(4).val())
 fair=fair.cut(wheelcut).cut(cq.Solid.makeCylinder(130,480,cq.Vector(rearax,-240,tz),cq.Vector(0,1,0)))
 for i,(x0,x1) in enumerate([(278,430),(430,665)],1):add(f'10_carenagem_{sign}_secao_{i}',fair.intersect(box([x0,-210,0],[x1,210,180])),orange)

# Ventilated grille mesh, separated into printable-width logical halves.
grille=(cq.Workplane('YZ',origin=(28,0,184)).rect(272,94).rect(266,88).extrude(3).val())
for y in np.arange(-126,127,12):grille=grille.fuse(box([28,float(y)-1,140],[31,float(y)+1,228]))
grille=grille.fuse(box([28,-133,182.5],[31,133,185.5]))
for i,(y0,y1) in enumerate([(-150,0),(0,150)],1):add(f'11_grade_ventilada_{i}',grille.intersect(box([20,y0,130],[40,y1,240])),dark)
for cy,ww in [(0,145),(-139,45),(139,45)]:
 screen=cq.Workplane('YZ',origin=(-18,cy,48)).rect(ww+4,38).rect(ww,32).extrude(2).val()
 for y in np.arange(cy-ww/2+4,cy+ww/2-3,8):screen=screen.fuse(box([-18,float(y)-.7,32],[-16,float(y)+.7,64]))
 add(f'11_tela_duto_{cy}',screen,dark)

# Front badge and mirrors, as separate components; no decorative sponsor lettering.
ring=cq.Solid.makeCylinder(33,3,cq.Vector(12,0,184),cq.Vector(1,0,0)).cut(cq.Solid.makeCylinder(28.5,5,cq.Vector(11,0,184),cq.Vector(1,0,0)))
badge=ring
for deg in [90,210,330]:
 a=np.radians(deg);b=np.array([np.cos(a),np.sin(a)]);t=np.array([-b[1],b[0]])
 pts=[(-t*3.).tolist(),(b*29+t*1.5).tolist(),(b*29-t*1.5).tolist()]
 spoke=cq.Workplane('YZ',origin=(12,0,184)).polyline(pts).close().extrude(3).val();badge=badge.fuse(spoke)
for angle in [90,210,330]:
 aa=np.radians(angle);yy=30.75*np.cos(aa);zz=184+30.75*np.sin(aa)
 badge=badge.fuse(cq.Solid.makeCylinder(1.8,9,cq.Vector(15,float(yy),float(zz)),cq.Vector(1,0,0)))
add('11_emblema_frontal',badge,silver)
for sign in [-1,1]:
 mirror=box([30,sign*212-6,302],[54,sign*212+6,349]).fillet(3,[]) if False else box([30,sign*212-6,302],[54,sign*212+6,349])
 arm=cq.Solid.makeCylinder(3,39,cq.Vector(40,sign*175,320),cq.Vector(0,sign,0));add(f'12_espelho_{sign}',mirror.fuse(arm),dark)
# Guide tires only: they are NOT functional wheel files to manufacture.
for cx in [ax,P['eixo_traseiro_x_provisorio']]:
 for sign in [-1,1]:
  y0=148 if sign>0 else -200
  tire=cq.Solid.makeCylinder(tz,52,cq.Vector(cx,y0,tz),cq.Vector(0,1,0))
  add(f'pneu_referencia_{cx}_{sign}',tire,dark,'referencia')

assembly=cq.Assembly(name='ESTUDO_FORMULA_TRUCK_400MM')
records=[]
(O/'COMPONENTES_LOGICOS').mkdir(exist_ok=True)
for p in parts:
 cq.exporters.export(p['shape'],str(O/'COMPONENTES_LOGICOS'/(p['name']+'.step')))
 assembly.add(p['shape'],name=p['name'],color=cq.Color(*p['color']));bb=p['shape'].BoundingBox();records.append(dict(nome=p['name'],volume_mm3=p['shape'].Volume(),dimensoes_xyz_mm=[bb.xlen,bb.ylen,bb.zlen],solido_valido=p['shape'].isValid()))
assembly.export(str(O/'ESTUDO_CARROCERIA_400MM.step'))
(O/'inventario_estudo.json').write_text(json.dumps(dict(status='PROVISORIO_NAO_E_KIT_DE_IMPRESSAO',largura_nominal_mm=400,pecas=records,fixacoes_chassi=False,encaixes_definitivos=False),indent=2))
print('STUDY',len(parts),'componentes logicos',len(refs),'referencias',flush=True)
np.savez(R/'estado_estudo.npz',dummy=np.array([1]))
sys.path.insert(0,'/workspace/REAR_BODY_NOVO');from render_vtk import render
# CQ native tessellation -> normals from VTK supplied by the renderer.
allparts=parts+refs
render(allparts,O/'ESTUDO_PERSPECTIVA.png',azimuth=-145,elevation=18,size=(1700,1100))
render(allparts,O/'ESTUDO_LATERAL.png',azimuth=-90,elevation=0,size=(1700,1000))
print('ESTUDO STEP E IMAGENS GERADOS',flush=True)
