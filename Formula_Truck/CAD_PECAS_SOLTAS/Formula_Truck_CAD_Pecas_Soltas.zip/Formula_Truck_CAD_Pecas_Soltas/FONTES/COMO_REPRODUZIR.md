# Reprodução do CAD

Requer Python 3.12, compilador C `cc` para imagens e dependências em requirements-ambiente.txt. Execute na pasta FONTES, em uma cópia de trabalho:

```
python estudo.py
python dividir_cabine.py
python entregar_cad.py
```

Os resultados são gerados em FONTES/ESTUDO_01 e FONTES/CAD_ENTREGA, sem sobrescrever automaticamente os arquivos finais da pasta superior do ZIP. O primeiro script desenha as formas lógicas; o segundo subdivide a cabine; o terceiro exporta as peças soltas, os STL e as montagens, verificando os arquivos e o envelope da impressora.

Os scripts foram usados na preparação. Os caminhos relativos desta cópia foram conferidos, mas a reconstrução integral a partir do pacote não foi repetida em um ambiente novo. Para adaptar formas, confira tanto parametros_estudo.json quanto os valores geométricos no código: nem tudo está vinculado ao JSON. Para modificar no próprio Fusion, abra os STEP individuais ou a montagem.
