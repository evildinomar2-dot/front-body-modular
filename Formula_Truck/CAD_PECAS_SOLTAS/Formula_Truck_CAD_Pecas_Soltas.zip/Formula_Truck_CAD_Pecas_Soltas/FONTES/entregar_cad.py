from pathlib import Path
import cadquery as cq,numpy as np,trimesh,json,itertools,csv
R=Path(__file__).resolve().parent;I=R/'ESTUDO_01';O=R/'CAD_ENTREGA'
for n in ['STEP_PECAS','STEP_VIDROS_OPCIONAIS','STL_PECAS','STL_IMPRESSAO','STL_VIDROS_OPCIONAIS','FONTES']:(O/n).mkdir(parents=True,exist_ok=True)
orange=(.94,.22,.035);dark=(.10,.12,.14);silver=(.62,.67,.72);glass=(.23,.35,.42)
parts=[]
def box(lo,hi):return cq.Solid.makeBox(*[hi[i]-lo[i] for i in range(3)],cq.Vector(*lo))
def add(name,shape,color,optional=False):
 for i,s in enumerate(shape.Solids()):
  if s.Volume()<.1:continue
  assert s.isValid(),name
  parts.append(dict(name=name+(f'_{i+1}' if len(shape.Solids())>1 else ''),shape=s,color=color,optional=optional))
# Replace the five large logical cab pieces with their twenty native CAD panels.
for p in sorted((I/'DIVISAO_CABINE').glob('*.step')):add('01_cabine_'+p.stem,cq.importers.importStep(str(p)).val(),orange)
for p in sorted((I/'COMPONENTES_LOGICOS').glob('*.step')):
 if p.stem[:2] in ['01','02','03','04','05']:continue
 s=cq.importers.importStep(str(p)).val();color=dark if 'grade' in p.stem or 'tela' in p.stem or 'espelho' in p.stem else silver if 'emblema' in p.stem else orange
 if p.stem.startswith(('08_','09_')):
  b=s.BoundingBox();middle=(b.xmin+b.xmax)/2
  for i,(lo,hi) in enumerate([(b.xmin-1,middle),(middle,b.xmax+1)],1):add(p.stem+f'_parte_{i}',s.intersect(box([lo,b.ymin-1,b.zmin-1],[hi,b.ymax+1,b.zmax+1])),color)
 else:add(p.stem,s,color)
body_count=len(parts)
# Optional glazing solids were already part of the approved visual study.
for p in sorted((I/'VIDROS_REFERENCIA').glob('*.step')):
 s=cq.importers.importStep(str(p)).val();color=(.9,.9,.87) if 'faixa_' in p.stem else glass
 if 'lateral' in p.stem:add('vidro_opcional_'+p.stem,s,color,True)
 else:
  b=s.BoundingBox()
  for i,(lo,hi) in enumerate([(b.ymin-1,0),(0,b.ymax+1)],1):add('vidro_opcional_'+p.stem+f'_parte_{i}',s.intersect(box([b.xmin-1,lo,b.zmin-1],[b.xmax+1,hi,b.zmax+1])),color,True)

records=[];body_assembly=cq.Assembly(name='FORMULA_TRUCK_CARROCERIA_400');full=cq.Assembly(name='FORMULA_TRUCK_COM_VIDROS_OPCIONAIS')
def ascii_stl(m,path):
 with path.open('w') as stream:
  stream.write('solid formula_truck\n')
  for normal,tri in zip(m.face_normals,m.triangles):
   stream.write('facet normal '+' '.join(format(float(x),'.17g') for x in normal)+'\nouter loop\n')
   for point in tri:stream.write('vertex '+' '.join(format(float(x),'.17g') for x in point)+'\n')
   stream.write('endloop\nendfacet\n')
  stream.write('endsolid formula_truck\n')
for part in parts:
 name,s,color,opt=[part[k] for k in ['name','shape','color','optional']];b=s.BoundingBox();dims=np.array([b.xlen,b.ylen,b.zlen]);choices=[]
 for perm in itertools.permutations([0,1,2]):
  d=dims[list(perm)]
  if np.all(d<=[218.0001,218.0001,248.0001]):choices.append((d[2],perm,d))
 assert choices,(name,dims)
 _,perm,d=min(choices,key=lambda x:x[0]);mat=np.zeros((4,4));mat[3,3]=1
 for row,axis in enumerate(perm):mat[row,axis]=1
 if np.linalg.det(mat[:3,:3])<0:mat[0,:3]*=-1
 assert abs(np.linalg.det(mat[:3,:3])-1)<1e-8
 verts,faces=s.tessellate(.03,.10);m=trimesh.Trimesh(np.array([v.toTuple() for v in verts]),np.array(faces),process=True)
 for digits in [7,6,5]:
  if m.is_volume:break
  m.merge_vertices(digits_vertex=digits);m.update_faces(m.unique_faces());m.update_faces(m.nondegenerate_faces(height=1e-9));m.remove_unreferenced_vertices()
 if not m.is_winding_consistent:m.fix_normals()
 assert m.is_volume,(name,'STL invalid')
 printed=m.copy();printed.apply_transform(mat);shift=np.array([2-printed.bounds[0,0],2-printed.bounds[0,1],-printed.bounds[0,2]]);printed.apply_translation(shift)
 assert np.all(printed.extents<=[218.0001,218.0001,248.0001])
 folder='STEP_VIDROS_OPCIONAIS' if opt else 'STEP_PECAS';target=O/folder/(name+'.step');cq.exporters.export(s,str(target));q=cq.importers.importStep(str(target)).val();assert q.isValid() and len(q.Solids())==1
 assert abs(s.Volume()-q.Volume())<max(.02,s.Volume()*1e-6)
 stlfolder='STL_VIDROS_OPCIONAIS' if opt else 'STL_PECAS';stl=O/stlfolder/(name+'.stl');ascii_stl(m,stl);assert trimesh.load_mesh(stl).is_volume
 stlprint=O/'STL_IMPRESSAO'/(name+'.stl');ascii_stl(printed,stlprint);assert trimesh.load_mesh(stlprint).is_volume
 assert abs(printed.volume-m.volume)<max(.001,m.volume*1e-8)
 if not opt:body_assembly.add(q,name=name,color=cq.Color(*color))
 full.add(q,name=name,color=cq.Color(*color))
 records.append(dict(nome=name,vidro_opcional=opt,solidos=1,cad_valido=True,step_reimportado=True,stl_fechado=True,volume_cad_mm3=s.Volume(),dimensoes_montagem_mm=dims.tolist(),dimensoes_orientadas_mm=printed.extents.tolist(),matriz_rotacao_impressao=mat.tolist(),translacao_impressao=shift.tolist(),cabe_envelope_218_218_248=True,unioes_mecanicas_detalhadas=False,adaptacao_chassi=False))
 print('PECAS OK',len(records),len(parts),name,flush=True)
body_assembly.export(str(O/'MONTAGEM_TRUCK_CARROCERIA.step'));full.export(str(O/'MONTAGEM_TRUCK_COM_VIDROS.step'))
for filename,count in [('MONTAGEM_TRUCK_CARROCERIA.step',body_count),('MONTAGEM_TRUCK_COM_VIDROS.step',len(parts))]:
 q=cq.importers.importStep(str(O/filename)).val();assert q.isValid() and len(q.Solids())==count;print('MONTAGEM OK',filename,count,flush=True)
(O/'validacao_pecas.json').write_text(json.dumps(dict(tipo='CAD_BASE_PECAS_SOLTAS',adaptacao_chassi_por_usuario=True,unioes_e_travas_nao_detalhadas=True,carroceria=body_count,vidros_opcionais=len(parts)-body_count,total=len(parts),entre_eixos_mm=500,diametro_roda_referencia_mm=200,largura_externa_pneus_mm=400,impressora_mm=[220,220,250],envelope_mm=[218,218,248],desvio_tesselacao_stl_mm=.03,montagens_reimportadas_validas=True,pecas=records),indent=2))
with (O/'LISTA_PECAS.csv').open('w',newline='') as stream:
 w=csv.writer(stream);w.writerow(['arquivo','tipo','quantidade','X_impressao_mm','Y_impressao_mm','Z_impressao_mm'])
 for p in records:w.writerow([p['nome'],'vidro opcional' if p['vidro_opcional'] else 'carroceria',1,*[round(float(v),3) for v in p['dimensoes_orientadas_mm']]])
print('ENTREGA CAD COMPLETA',body_count,'carroceria',len(parts)-body_count,'opcionais',flush=True)
