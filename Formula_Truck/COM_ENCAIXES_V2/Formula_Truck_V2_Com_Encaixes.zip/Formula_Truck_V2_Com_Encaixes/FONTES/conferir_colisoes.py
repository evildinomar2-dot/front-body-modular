from pathlib import Path
from OCP.BRepTools import BRepTools
from OCP.BRepMesh import BRepMesh_IncrementalMesh
import cadquery as cq,numpy as np,trimesh,manifold3d as md,json,itertools
R=Path(__file__).resolve().parent/'COM_ENCAIXES';D=R/'MALHAS_CONFERENCIA';D.mkdir(exist_ok=True)
parts=[];bad=[]
for folder in ['STEP_PECAS','STEP_VIDROS_OPCIONAIS','STEP_CHAVETAS']:
 for f in sorted((R/folder).glob('*.step')):
  s=cq.importers.importStep(str(f)).val();BRepTools.Clean_s(s.wrapped);BRepMesh_IncrementalMesh(s.wrapped,.025,False,.10,True).Perform();verts,faces=s.tessellate(.025,.10)
  m=trimesh.Trimesh(np.array([v.toTuple() for v in verts]),np.array(faces),process=True)
  for digits in [7,6,5]:
   if m.is_volume:break
   m.merge_vertices(digits_vertex=digits);m.update_faces(m.unique_faces());m.update_faces(m.nondegenerate_faces(height=1e-9));m.remove_unreferenced_vertices()
  if not m.is_winding_consistent:m.fix_normals()
  if not m.is_volume:
   bad.append(f.stem);print('MALHA_PROVISORIA_REPARADA',f.stem,flush=True)
   import pymeshfix
   fix=pymeshfix.MeshFix(m.vertices,m.faces);fix.repair(joincomp=True,remove_smallest_components=False)
   m=trimesh.Trimesh(fix.points,fix.faces,process=True);assert m.is_volume

  m.export(D/(f.stem+'.ply'))
  v=np.ascontiguousarray(m.vertices,dtype=np.float32);tri=np.ascontiguousarray(m.faces,dtype=np.uint32)
  mani=md.Manifold(md.Mesh(v,tri));assert str(mani.status())=='Error.NoError',(f.name,mani.status())
  parts.append(dict(name=f.stem,s=s,m=m,mani=mani,lo=m.bounds[0],hi=m.bounds[1]))
  print('MALHA',len(parts),f.stem,flush=True)
collisions=[]
for i,a in enumerate(parts):
 for j,b in enumerate(parts[:i]):
  overlap=np.minimum(a['hi'],b['hi'])-np.maximum(a['lo'],b['lo'])
  if np.any(overlap<.005):continue
  inter=a['mani']^b['mani'];vol=inter.volume()
  if vol>.15:
   rec=dict(a=a['name'],b=b['name'],volume_mm3=vol);collisions.append(rec);print('COLISAO',a['name'],b['name'],round(vol,4),flush=True)
# Tire reference volume is used solely as a keep-out, not delivered as functional tires.
tires=[]
for x in [185,685]:
 for sign in [-1,1]:
  s=cq.Solid.makeCylinder(100,52,cq.Vector(x,148 if sign>0 else -200,100),cq.Vector(0,1,0))
  vv,ff=s.tessellate(.08,.12);m=trimesh.Trimesh([v.toTuple() for v in vv],ff,process=True)
  tires.append(md.Manifold(md.Mesh(np.asarray(m.vertices,dtype=np.float32),np.asarray(m.faces,dtype=np.uint32))))
tire_hits=[]
for p in parts:
 for i,t in enumerate(tires):
  vol=(p['mani']^t).volume()
  if vol>.15:tire_hits.append(dict(peca=p['name'],pneu=i,volume_mm3=vol));print('PNEU',p['name'],i,vol,flush=True)
(R/'COLISOES.json').write_text(json.dumps(dict(tolerancia_volume_mm3=.15,desvio_malha_absoluto_mm=.025,colisoes=collisions,invasoes_pneus=tire_hits,total_pecas=len(parts),malhas_reparadas_apenas_para_diagnostico=bad),indent=2))
print('CONFERENCIA',len(parts),'colisoes',len(collisions),'pneus',len(tire_hits),flush=True)
