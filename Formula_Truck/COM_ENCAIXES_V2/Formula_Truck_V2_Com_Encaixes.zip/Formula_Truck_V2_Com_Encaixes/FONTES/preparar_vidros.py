from pathlib import Path
import cadquery as cq,numpy as np
R=Path(__file__).resolve().parent;O=R/'VIDROS_COM_FOLGA';O.mkdir(exist_ok=True)
for f in sorted((R/'CAD_ENTREGA/STEP_VIDROS_OPCIONAIS').glob('*.step')):
 s=cq.importers.importStep(str(f)).val();b=s.BoundingBox();c=np.array([(b.xmax+b.xmin)/2,(b.ymax+b.ymin)/2,(b.zmax+b.zmin)/2]);d=np.array([b.xlen,b.ylen,b.zlen]);factors=np.ones(3)
 axes=[0,2] if 'lateral' in f.stem else [1,2]
 for ax in axes:factors[ax]=(d[ax]-.4)/d[ax]
 mat=np.eye(4);mat[:3,:3]=np.diag(factors);mat[:3,3]=c-c*factors
 t=s.transformGeometry(cq.Matrix(mat.tolist()));assert t.isValid() and len(t.Solids())==1
 cq.exporters.export(t,str(O/f.name));print('VIDRO COM FOLGA',f.name,flush=True)
