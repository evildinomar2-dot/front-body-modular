"""Unioes coladas: pontes internas de duas chavetas retangulares, folga 0.2 mm/face."""
from pathlib import Path
import cadquery as cq, numpy as np, json,itertools,sys
from OCP.IntCurvesFace import IntCurvesFace_ShapeIntersector
from OCP.gp import gp_Lin,gp_Pnt,gp_Dir
R=Path(__file__).resolve().parent;O=R/'COM_ENCAIXES';O.mkdir(exist_ok=True)
for d in ['STEP_PECAS','STEP_CHAVETAS','STEP_VIDROS_OPCIONAIS']:(O/d).mkdir(exist_ok=True)
parts=[]
for folder,opt in [('STEP_PECAS',False),('STEP_VIDROS_OPCIONAIS',True)]:
 for f in sorted((R/'CAD_ENTREGA'/folder).glob('*.step')):
  source=R/'VIDROS_COM_FOLGA'/f.name if opt else f
  parts.append(dict(name=f.stem,shape=cq.importers.importStep(str(source)).val(),optional=opt))
original=[p['shape'] for p in parts]
# Screen reference frames used to touch the bumper wall: place them behind it.
for i in [42,43,44]:
 parts[i]['shape']=parts[i]['shape'].translate((15,0,0));original[i]=parts[i]['shape']
J=[]
def add(a,b,pa,pb,n,label=''):
 J.append(dict(a=a,b=b,pa=pa,pb=pb,n=n,label=label))
# Front panel center, horizontal divisions, and front-to-side returns.
for z,a,b in [(120,0,1),(410,2,3)]:add(a,b,[24,-9,z],[24,9,z],[-1,0,0],'frente centro')
for s,a,b in [(-1,0,2),(1,1,3)]:
 for y in [167]:
  # At y=0 use one side of the central split so the boss remains in that panel.
  yy=s*(9 if y==0 else y);add(a,b,[23,yy,242],[23,yy,255],[-1,0,0],'frente horizontal')
for s,fr,fu,la,lu,lb,lv,back,bup in [(-1,0,2,4,5,6,7,16,18),(1,1,3,8,9,10,11,17,19)]:
 n=[0,s,0]
 for z,a,b in [(220,fr,la),(410,fu,lu)]:add(a,b,[62,s*184,z],[78,s*184,z],n,'canto frente lateral')
 add(la,lb,[103,s*184,222],[117,s*184,222],n,'lateral vertical inferior')
 add(lu,lv,[103,s*178,413],[117,s*178,413],n,'lateral vertical superior')
 for x,a,b in [(90,la,lu),(300,lb,lv)]:add(a,b,[x,s*184,229],[x,s*184,241],n,'lateral horizontal')
 for z,a,b in [(205,lb,back),(375,lv,bup)]:add(a,b,[303,s*183,z],[317,s*183,z],n,'canto lateral traseira')
# Back center and horizontal seams.
for z,a,b in [(221,16,17),(375,18,19)]:add(a,b,[340,-8,z],[340,8,z],[1,0,0],'traseira centro')
for s,a,b in [(-1,16,18),(1,17,19)]:
 for y in [65,150]:add(a,b,[340,s*y,253],[340,s*y,267],[1,0,0],'traseira horizontal')
# Roof quarters, and roof-to-front/side/back returns.
for a,b,x in [(12,13,110),(14,15,270)]:add(a,b,[x,-8,448],[x,8,448],[0,0,1],'teto centro')
for s,a,b in [(-1,12,14),(1,13,15)]:
 for y in [65,145]:add(a,b,[182,s*y,448],[198,s*y,448],[0,0,1],'teto transversal')
for s,fr,side1,side2,bk,rf,rr in [(-1,2,5,7,18,12,14),(1,3,9,11,19,13,15)]:
 add(fr,rf,[52,s*161,411],[55,s*161,425],[-1,0,0],'teto frente')
 for x,a,b in [(155,side2,rf),(285,side2,rr)]:add(a,b,[x,s*177,411],[x,s*177,425],[0,s,0],'teto lateral')
 add(bk,rr,[327,s*125,411],[327,s*125,425],[1,0,0],'teto traseira')
# Bumper divisions, lip divisions and lip-to-bumper.
for s,a in [(-1,20),(1,23)]:
 add(a,21,[-4,s*75,87],[-4,s*59,87],[-1,0,0],'parachoque superior')
 add(a,22,[-25,s*75,25],[-25,s*59,25],[-1,0,0],'parachoque inferior')
 lip=24 if s<0 else 26
 for x in [12,50]:add(lip,25,[x,s*75,19],[x,s*59,19],[0,0,-1],'lamina centro')
 # Fix the bumper to lower front panels, away from all grille openings.
 body=0 if s<0 else 1
 add(a,body,[3,s*177,88],[24,s*177,109],[-1,0,0],'parachoque cabine')
 # Vertical insertion through lip into bumper bottom wall, at the side return.
 add(lip,a,[48,s*191,19],[48,s*196,39],[0,s,0],'lamina parachoque lateral')
# Central lip connects to bottom strip through an underside key near the front edge.
add(25,22,[-24,-48,19],[-24,-30,26],[-1,0,0],'lamina parachoque centro');J[-1]['corrigir_direcao']=True
# Every wheel arch is split in two. Keys sit over the tire clearance.
for a,b,cx in [(27,28,185),(29,30,185),(31,32,685),(33,34,685)]:
 s=-1 if a in [27,31] else 1
 for y in [175,190]:add(a,b,[cx-8,s*y,225],[cx+8,s*y,225],[0,0,1],'coroa paralama')
# Fairing halves and wheel-arch attachments.
for s,fa,fb,archfront,archrear,cab in [(-1,35,36,28,31,7),(1,37,38,30,33,11)]:
 for z in [49,128]:add(fa,fb,[422,s*192,z],[438,s*192,z],[0,s,0],'carenagem centro')
 add(archfront,fa,[300,s*180,145],[355,s*192,145],[0,s,0],'paralama carenagem frente')
 add(fb,archrear,[549,s*192,145],[570,s*180,145],[0,s,0],'carenagem paralama traseiro')
 for x,arch in [(170,archfront-1),(200,archfront)]:add(arch,cab,[x,s*180,224],[x,s*184,241],[0,s,0],'paralama cabine')
# Grilles. Bridges land on the solid frame rails, not on open mesh.
add(40,41,[29,-8,229.5],[29,8,229.5],[-1,0,0],'grade centro')
for s,gr,fr in [(-1,40,0),(1,41,1)]:
 for y in [65,122]:add(gr,fr,[29,s*y,229.5],[22,s*y,240],[-1,0,0],'grade frente')
for screen,cy,bum in [(42,-139,20),(43,0,21),(44,139,23)]:
 # A screen's top rail is only 3 mm tall; use a compact receiver allowed to reinforce it internally.
 for dy in ([-45,45] if screen==43 else [-12,12]):add(screen,bum,[-2,cy+dy,65.5],[-2,cy+dy,78],[-1,0,0],'tela duto')
# Existing round stems: preserve their 0.25 mm radial clearance and glue; ensure insertion.
# Front badge is given an additional central rear alignment tongue below the grille center bar.
# Badge uses its three existing round locating pins, with 0.2 mm radial clearance.
# Optional glazing: split windscreen and strips, all located by internal keys.
# Optional indices: 47/48 bottom strips,49/50 top strips,51/52 windscreen,53/54 side windows.
for a,b,z in [(47,48,268),(49,50,389),(51,52,325)]:add(a,b,[30,-8,z],[30,8,z],[-1,0,0],'vidro centro')
for s,bottom,top,wind,fr,sideglass,side in [(-1,47,49,51,2,53,7),(1,48,50,52,3,54,11)]:
 add(bottom,wind,[30,s*95,273],[30,s*95,287],[-1,0,0],'faixa inferior vidro')
 add(wind,top,[30,s*95,370],[30,s*95,384],[-1,0,0],'vidro faixa superior')
 add(wind,fr,[30,s*139,325],[30,s*159,325],[-1,0,0],'vidro coluna frontal')
 for x in [155,260]:add(sideglass,side,[x,s*180,256],[x,s*184,241],[0,s,0],'vidro lateral')

# Rays are measured on the original solid. n always points towards the outer skin.
def hits(s,p,n):
 inter=IntCurvesFace_ShapeIntersector();inter.Load(s.wrapped,1e-7)
 inter.Perform(gp_Lin(gp_Pnt(*[float(x) for x in p]),gp_Dir(*[float(x) for x in n])),-100,100)
 ts=sorted(set(round(inter.WParameter(k),7) for k in range(1,inter.NbPnt()+1)))
 intervals=[]
 for a,b in zip(ts,ts[1:]):
  mid=p+n*(a+b)/2
  if b-a>.05 and s.isInside(cq.Vector(*mid),1e-6):intervals.append((a,b))
 if not intervals:return None
 return min(intervals,key=lambda z:abs(sum(z)/2))
def prism(center,u,n,du,dv,h):
 return cq.Workplane(cq.Plane(origin=cq.Vector(*center),xDir=cq.Vector(*u),normal=cq.Vector(*n))).rect(du,dv).extrude(h).val()
keys=[];reports=[]
# Small receivers for the narrow grille/duct rails. Wider ones for structural panels.
import hashlib
for idx,j in enumerate(J,1):
 cacheid=hashlib.sha256(('v4'+json.dumps(J[:idx],sort_keys=True)).encode()).hexdigest()[:24]
 cache=R/'CACHE_ENCAIXES'/cacheid;cache.mkdir(parents=True,exist_ok=True)
 if (cache/'report.json').exists():
  a,b=j['a'],j['b'];parts[a]['shape']=cq.Shape.importBrep(str(cache/'a.brep'));parts[b]['shape']=cq.Shape.importBrep(str(cache/'b.brep'))
  report=json.loads((cache/'report.json').read_text());reports.append(report)
  keys.append(dict(name=report['arquivo'],shape=cq.Shape.importBrep(str(cache/'key.brep')),optional=report['vidro_opcional']))
  print('CACHE',idx,len(J),flush=True);continue
 a,b=j['a'],j['b'];n=np.array(j['n'],float);n/=np.linalg.norm(n)
 pa,pb=np.array(j['pa'],float),np.array(j['pb'],float)
 delta=pb-pa;delta-=n*np.dot(delta,n);u=delta/np.linalg.norm(delta);v=np.cross(n,u)
 endpoints=[]
 for number,p in [(a,pa),(b,pb)]:
  result=hits(original[number],p,n)
  lip_override=number in [24,25,26] and abs(n[2])<.5
  if lip_override:
   inner=p.copy();inner[2]+=6
   outer=inner.copy()
   if abs(n[1])>.5:outer[1]=196*np.sign(n[1])
   else:
    inner[0]=-17;outer[0]=-21
   endpoints.append((number,inner,outer));continue
  if result is None:
   print('MISSING RAY',idx,number,parts[number]['name'],p.tolist(),j['label'],flush=True);raise RuntimeError('ray missing')
  enter,exit=result;inner=p+n*enter;outer=p+n*exit
  endpoints.append((number,inner,outer))
 delta=endpoints[1][1]-endpoints[0][1];delta-=n*np.dot(delta,n);u=delta/np.linalg.norm(delta);v=np.cross(n,u)
 base=min(np.dot(inn,n) for _,inn,_ in endpoints)-5.5
 if j['label']=='paralama carenagem frente':base-=8
 # A universal 8 x 10 mm receiver; clipping is not used so narrow rails receive local reinforcement.
 inserts=[];bosses=[];sockets=[];bossmeta=[]
 for number,inner,outer in endpoints:
  q=inner+n*(base-np.dot(inner,n))
  # The face towards the outside is recessed at least 0.6 mm below the skin at the center.
  # Structural sloped skins use nearby rays to choose a conservative outer limit.
  tops=[np.dot(outer,n)]
  for uu in [-4,0,4]:
   for vv in [-5,0,5]:
    rr=hits(original[number],inner+uu*u+vv*v,n)
    if rr:tops.append(np.dot(inner+uu*u+vv*v+n*rr[1],n))
  top=min(tops)-.6
  if top<np.dot(inner,n)+.4:
   # Ensure the block joins the original at its center. The local top is later checked for external projection.
   top=np.dot(inner,n)+.6
  boss=prism(q,u,n,7.8,9.8,top-base)
  if number in [24,25,26] and abs(n[2])<.5:
   # A foot joins the new socket to the horizontal lip, while the loose key stays above it.
   foot_shift=min(0,19-boss.BoundingBox().zmin)
   if foot_shift<0:boss=boss.fuse(boss.translate((0,0,foot_shift)))
  common=original[number].intersect(boss).Volume()
  if common<.5:
   print('BOSS NOT ATTACHED',idx,number,common,flush=True);raise RuntimeError('boss disconnected')
  socket=prism(q-.03*n,u,n,3.6,5.6,4.53)
  # Wider 0.4 mm lead-in at the mouth, keeping the working clearance at 0.2 mm/face.
  socket=socket.fuse(prism(q-.03*n,u,n,4.0,6.0,.53))
  new=parts[number]['shape'].fuse(boss).cut(socket).clean()
  if not new.isValid() or len(new.Solids())!=1:
   print('INVALID RECEIVER',idx,number,len(new.Solids()),flush=True);raise RuntimeError('invalid receiver')
  parts[number]['shape']=new
  # 4.2 mm from plate top; 0.2 mm mouth gap -> 4 mm effective insertion, 0.5 mm bottom clearance.
  pegbase=q-.2*n
  peg=prism(pegbase,u,n,3.2,5.2,3.7)
  plane=cq.Plane(origin=cq.Vector(*(pegbase+3.7*n)),xDir=cq.Vector(*u),normal=cq.Vector(*n))
  tip=cq.Workplane(plane).rect(3.2,5.2).workplane(offset=.5).rect(2.4,4.4).loft().val()
  inserts.append(peg.fuse(tip));bosses.append(boss);sockets.append(socket)
  bossmeta.append(dict(peca=parts[number]['name'],ponto_interno=inner.tolist(),ponto_chaveta=q.tolist(),sobreposicao_boss_original_mm3=common,altura_boss_mm=top-base))
 qa=endpoints[0][1]+n*(base-np.dot(endpoints[0][1],n));qb=endpoints[1][1]+n*(base-np.dot(endpoints[1][1],n))
 center=(qa+qb)/2-n*2.6;length=np.linalg.norm(qb-qa)+8
 plate=prism(center,u,n,length,8,2.4)
 key=plate.fuse(*inserts).clean()
 assert key.isValid() and len(key.Solids())==1,(idx,'invalid key')
 name=f'CH{idx:03d}_{j["label"].replace(" ","_")}'
 keys.append(dict(name=name,shape=key,optional=parts[a]['optional'] or parts[b]['optional']))
 reports.append(dict(id=f'CH{idx:03d}',arquivo=name,peca_A=parts[a]['name'],peca_B=parts[b]['name'],indices=[a,b],normal_insercao=n.tolist(),largura_macho_mm=3.2,comprimento_macho_mm=5.2,folga_por_face_mm=.2,insercao_mm=4,profundidade_alojamento_mm=4.5,bosses=bossmeta,vidro_opcional=keys[-1]['optional']))
 parts[a]['shape'].exportBrep(str(cache/'a.brep'));parts[b]['shape'].exportBrep(str(cache/'b.brep'));key.exportBrep(str(cache/'key.brep'))
 (cache/'report.json').write_text(json.dumps(reports[-1]))
 print('UNIAO',idx,len(J),a,b,j['label'],flush=True)
# Mirror arms already pass through the original clearance holes. Glue them in place.
# Check all supplied pieces belong to the assembly graph, including optional glazing.
import networkx as nx
G=nx.Graph();G.add_nodes_from(range(len(parts)))
G.add_edges_from((j['a'],j['b']) for j in J);G.add_edges_from([(45,2),(46,3),(39,0),(39,1)])
assert nx.is_connected(G),list(nx.connected_components(G))
assembly=cq.Assembly(name='TRUCK_COM_ENCAIXES_COLADOS')
for p in parts:
 name,s,opt=p['name'],p['shape'],p['optional'];folder='STEP_VIDROS_OPCIONAIS' if opt else 'STEP_PECAS'
 cq.exporters.export(s,str(O/folder/(name+'.step')))
 color=(.2,.45,.65) if opt else (.12,.14,.16) if any(t in name for t in ['grade','tela','espelho']) else (.94,.22,.035)
 assembly.add(s,name=name,color=cq.Color(*color))
for stale in (O/'STEP_CHAVETAS').glob('*.step'):stale.unlink()
for k in keys:
 cq.exporters.export(k['shape'],str(O/'STEP_CHAVETAS'/(k['name']+'.step')))
 assembly.add(k['shape'],name=k['name'],color=cq.Color(.9,.72,.15))
assembly.export(str(O/'MONTAGEM_COM_ENCAIXES.step'))
(O/'MAPA_UNIOES.json').write_text(json.dumps(dict(versao=2,tipo='chavetas_internas_para_colar',folga_por_face_mm=.2,sem_fixacoes_chassi=True,grafo_55_pecas_conectado=True,espelhos='hastes redondas originais coladas em furos com folga radial de 0.25 mm',unioes=reports),indent=2))
print('GERACAO CONCLUIDA',len(parts),len(keys),flush=True)
