# Reprodução

Python 3.12 com as dependências de requirements.txt. Os STEP de CAD_ENTREGA são a base geométrica da revisão anterior. Na pasta FONTES, execute nesta ordem:

```
python preparar_vidros.py
python encaixes.py
python conferir_colisoes.py
python finalizar_encaixes.py
```

A saída é gerada em COM_ENCAIXES. O cache intermediário CACHE_ENCAIXES pode ser excluído para recalcular. preparar_vidros.py reduz os contornos dos vidros/faixas; encaixes.py adiciona reforços e alojamentos e cria as pontes; conferir_colisoes.py gera malhas com erro absoluto de 0,025 mm e verifica interpenetrações/pneus; finalizar_encaixes.py produz os STL orientados, teste e relatório.

As pastas CAD_ENTREGA preservam as formas anteriores como entrada; os arquivos a imprimir são os de saída com encaixes.
