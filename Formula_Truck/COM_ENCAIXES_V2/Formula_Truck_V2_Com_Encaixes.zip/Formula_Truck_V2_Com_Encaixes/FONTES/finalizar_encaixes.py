from pathlib import Path
import cadquery as cq,trimesh,numpy as np,json,itertools,csv,shutil
R=Path(__file__).resolve().parent;O=R/'COM_ENCAIXES'
col=json.loads((O/'COLISOES.json').read_text());assert not col['colisoes'] and not col['invasoes_pneus'] and not col['malhas_reparadas_apenas_para_diagnostico'],col
mapa=json.loads((O/'MAPA_UNIOES.json').read_text());unions={j['arquivo']:j for j in mapa['unioes']}
for d in ['STL_MONTAGEM','STL_IMPRESSAO','TESTE_ENCAIXE','FONTES']:(O/d).mkdir(exist_ok=True)
# Reference coupon uses exactly the pin, socket and plate dimensions of the assembly.
def zprism(x,y,z,dx,dy,h):return cq.Workplane('XY',origin=(x,y,z)).rect(dx,dy).extrude(h).val()
receiver=zprism(0,0,0,7.8,9.8,7).cut(zprism(0,0,2.5,3.6,5.6,4.6)).cut(zprism(0,0,6.5,4,6,.6)).clean()
key=zprism(0,0,0,24,8,2.4)
for x in [-8,8]:
 peg=zprism(x,0,2.4,3.2,5.2,3.7)
 tip=cq.Workplane('XY',origin=(x,0,6.1)).rect(3.2,5.2).workplane(offset=.5).rect(2.4,4.4).loft().val()
 key=key.fuse(peg,tip)
key=key.clean()
coupon=cq.Assembly(name='TESTE_ENCAIXE_02_POR_FACE')
for name,s,qty in [('TESTE_ALOJAMENTO_IMPRIMIR_2X',receiver,2),('TESTE_CHAVETA_IMPRIMIR_1X',key,1)]:
 assert s.isValid() and len(s.Solids())==1
 cq.exporters.export(s,str(O/'TESTE_ENCAIXE'/(name+'.step')))
 v,f=s.tessellate(.025,.1);m=trimesh.Trimesh([p.toTuple() for p in v],f,process=True);assert m.is_volume
 m.apply_translation(np.array([2,2,0])-m.bounds[0]);m.export(O/'TESTE_ENCAIXE'/(name+'.stl'))
 if qty==2:
  for x in [-8,8]:coupon.add(s.translate((x,0,0)),name=name+str(x),color=cq.Color(.94,.22,.035))
 else:
  assembled=s.rotate((0,0,0),(1,0,0),180).translate((0,0,9.6));coupon.add(assembled,name=name,color=cq.Color(.9,.72,.15))
  for x in [-8,8]:assert assembled.intersect(receiver.translate((x,0,0))).Volume()<1e-6
coupon.export(str(O/'TESTE_ENCAIXE/TESTE_MONTADO.step'))
records=[];mesh_by_name={}
for folder in ['STEP_PECAS','STEP_VIDROS_OPCIONAIS','STEP_CHAVETAS']:
 for f in sorted((O/folder).glob('*.step')):
  name=f.stem;s=cq.importers.importStep(str(f)).val();assert s.isValid() and len(s.Solids())==1
  meshfile=O/'MALHAS_CONFERENCIA'/(name+'.ply');m=trimesh.load_mesh(meshfile,process=True)
  assert m.is_volume,name
  assert abs(m.volume-s.Volume())<max(1,s.Volume()*.003),(name,'STL/CAD volume',m.volume,s.Volume())
  mesh_by_name[name]=m
  b=s.BoundingBox();dims=np.array([b.xlen,b.ylen,b.zlen]);rot=np.eye(4)
  if name in unions:
   n=np.array(unions[name]['normal_insercao']);candidate=np.array([1,0,0]) if abs(n[0])<.9 else np.array([0,1,0]);u=candidate-n*np.dot(candidate,n);u/=np.linalg.norm(u);v=np.cross(n,u);rot[:3,:3]=np.array([u,v,n])
  else:
   choices=[]
   for perm in itertools.permutations([0,1,2]):
    d=dims[list(perm)]
    if np.all(d<=[218.0001,218.0001,248.0001]):choices.append((d[2],perm))
   assert choices,(name,'nao cabe',dims)
   _,perm=min(choices);rot[:3,:3]=0
   for row,axis in enumerate(perm):rot[row,axis]=1
   if np.linalg.det(rot[:3,:3])<0:rot[0,:3]*=-1
  assert abs(np.linalg.det(rot[:3,:3])-1)<1e-8
  printed=m.copy();printed.apply_transform(rot);printed.apply_translation(np.array([2,2,0])-printed.bounds[0])
  assert np.all(printed.extents<=[218.0001,218.0001,248.0001]),(name,printed.extents)
  for target,mes in [('STL_MONTAGEM',m),('STL_IMPRESSAO',printed)]:
   out=O/target/(name+'.stl');mes.export(out);re=trimesh.load_mesh(out,process=True);assert re.is_volume,(name,'STL serializado')
  records.append(dict(nome=name,tipo='chaveta' if name in unions else 'vidro opcional' if folder=='STEP_VIDROS_OPCIONAIS' else 'carroceria',cad_valido=True,step_reimportado=True,stl_fechado=True,volume_cad_mm3=s.Volume(),volume_stl_mm3=float(m.volume),dimensoes_impressao_mm=printed.extents.tolist(),rotacao_impressao=rot.tolist()))
  print('ENTREGA VALIDADA',len(records),name,flush=True)
# Every socket still has an open cavity after all neighboring operations and STL export.
for j in mapa['unioes']:
 n=np.array(j['normal_insercao'])
 for boss in j['bosses']:
  p=np.array(boss['ponto_chaveta'])+n*2.25
  assert not mesh_by_name[boss['peca']].contains([p])[0],(j['id'],boss['peca'],'socket obstruido')
# STEP assembly contains the same independent solids as the individual files.
a=cq.importers.importStep(str(O/'MONTAGEM_COM_ENCAIXES.step')).val();assert a.isValid() and len(a.Solids())==len(records),(len(a.Solids()),len(records))
report=dict(status='CAD_COM_CHAVETAS_PARA_COLAR',carroceria=47,vidros_opcionais=8,chavetas=len(unions),total=len(records),folga_por_face_mm=.2,impressora_mm=[220,220,250],envelope_mm=[218,218,248],folga_fundo_alojamento_mm=.5,colisoes_volume_acima_015_mm3=0,invasoes_pneus_referencia=0,alojamentos_abertos_verificados=2*len(unions),malhas_reparadas=0,teste_fisico_realizado=False,fixacoes_chassi=False,pecas=records)
(O/'VALIDACAO.json').write_text(json.dumps(report,indent=2))
with (O/'LISTA_PECAS.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['arquivo','tipo','quantidade','X_impressao_mm','Y_impressao_mm','Z_impressao_mm'])
 for p in records:w.writerow([p['nome'],p['tipo'],1,*[round(x,3) for x in p['dimensoes_impressao_mm']]])
with (O/'MAPA_UNIOES.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['chaveta','peca_A','peca_B','opcional','direcao_insercao_X','Y','Z'])
 for j in mapa['unioes']:w.writerow([j['arquivo'],j['peca_A'],j['peca_B'],j['vidro_opcional'],*j['normal_insercao']])
print('PACOTE VALIDADO',len(records),'arquivos individuais',flush=True)
