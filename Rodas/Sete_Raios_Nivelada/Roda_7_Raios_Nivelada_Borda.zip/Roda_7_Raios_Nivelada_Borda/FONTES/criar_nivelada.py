from pathlib import Path
import cadquery as cq,numpy as np,trimesh,manifold3d as md,json
from OCP.BRepTools import BRepTools
from OCP.BRepMesh import BRepMesh_IncrementalMesh
R=Path(__file__).resolve().parent;O=R/'NIVELADA_BORDA';O.mkdir(exist_ok=True)
source=R/'Standar_Wheel.stl'
m=trimesh.load_mesh(source,process=True);m.apply_translation([54.3,0,0])
def mani(m):
 result=md.Manifold(md.Mesh(np.asarray(m.vertices,dtype=np.float32),np.asarray(m.faces,dtype=np.uint32)))
 assert str(result.status())=='Error.NoError',result.status()
 return result
def mesh(s):
 BRepTools.Clean_s(s.wrapped);BRepMesh_IncrementalMesh(s.wrapped,.015,False,.08,True).Perform();v,f=s.tessellate(.015,.08)
 m=trimesh.Trimesh([p.toTuple() for p in v],f,process=True)
 for dig in [7,6,5]:
  if m.is_volume:break
  m.merge_vertices(digits_vertex=dig);m.update_faces(m.unique_faces());m.update_faces(m.nondegenerate_faces(height=1e-10));m.remove_unreferenced_vertices()
 assert m.is_volume,'native mesh not closed'
 return m
orig=mani(m)
# Remove only the decorative interior and the five old spoke tips in front of the lip.
# The outer tire interfaces, latch details, rear bead and axle hub stay from the supplied STL.
profile=[(26,-28.3),(24.5,-26.8),(24.5,-26.3),(21.5,-20.3),(21.5,-6.8),(23,-5.3),(24,-5.3),(24,-4.3),(26,-2.3)]
# A 0.015 mm inset keeps the cutter clear of the original nominal barrel surface.
pts=[(0,-30),(26-.015,-30)]+[(r-.015,z) for r,z in profile]+[(0,-2.3)]
cutter=cq.Workplane('XZ').polyline(pts).close().revolve(360,(0,0,0),(0,1,0)).val()
barrel=orig-mani(mesh(cutter))
# Discard the old five spoke tips above the front lip. This is a cosmetic region.
frontcut=md.Manifold.cube([80,80,20]).translate([-40,-40,-2.3])
barrel=barrel-frontcut
hubmask=mani(mesh(cq.Solid.makeCylinder(8.5,19.7,cq.Vector(0,0,-30),cq.Vector(0,0,1))))
hub=orig^hubmask
# Rounded cross-sections give continuous smooth edges along each of the seven spokes.
def roundrect(r,width,top,thick,fillet=.32):
 w,h=width/2,thick/2;z=top-thick/2;f=min(fillet,w*.8,h*.8)
 return (cq.Workplane('YZ',origin=(r,0,z)).moveTo(-w+f,-h).lineTo(w-f,-h).radiusArc((w,-h+f),-f).lineTo(w,h-f).radiusArc((w-f,h),-f).lineTo(-w+f,h).radiusArc((-w,h-f),-f).lineTo(-w,-h+f).radiusArc((-w+f,-h),-f).close().val())
fronttop=-2.3  # plano da borda externa original, sem as antigas pontas levantadas
sections=[(7.9,5.0,fronttop,3.2),(10.4,3.3,fronttop,3.2),(16.5,2.35,fronttop,3.2),(22,2.15,fronttop,3.2),(25.8,2.8,fronttop,3.2),(26.8,3.2,fronttop,3.2)]
spoke=cq.Solid.makeLoft([roundrect(*s) for s in sections],False)
assert spoke.isValid()
collar=cq.Solid.makeCylinder(8.8,fronttop+13,cq.Vector(0,0,-13),cq.Vector(0,0,1))
lip=cq.Workplane('XY',origin=(0,0,-3.2)).circle(27.35).circle(25.6).extrude(fronttop+3.2).edges('>Z').fillet(.24).val()
face=collar
for i in range(7):face=face.fuse(spoke.rotate((0,0,0),(0,0,1),90+i*360/7))
face=face.fuse(lip).clean()
# Preserve every original axle/hub feature through the original front face.
protect=cq.Solid.makeCylinder(8.5,19.98,cq.Vector(0,0,-30.3),cq.Vector(0,0,1))
face=face.cut(protect)
# Recessed access well leaves the original axle-fastener seating plane untouched.
access=cq.Solid.makeCylinder(5,fronttop+10.45,cq.Vector(0,0,-10.35),cq.Vector(0,0,1))
cap_seat=cq.Solid.makeCylinder(5.5,.7,cq.Vector(0,0,fronttop-.6),cq.Vector(0,0,1))
face=face.cut(access.fuse(cap_seat))
for i in range(5):
 a=np.radians(90+i*72);x,y=7.35*np.cos(a),7.35*np.sin(a)
 recess=cq.Solid.makeCylinder(.80,1.1,cq.Vector(float(x),float(y),fronttop-.9),cq.Vector(0,0,1))
 chamfer=cq.Solid.makeCone(.80,1.0,.20,cq.Vector(float(x),float(y),fronttop-.20),cq.Vector(0,0,1))
 face=face.cut(recess.fuse(chamfer))
face=face.clean();assert face.isValid() and len(face.Solids())==1
face=face.intersect(cq.Solid.makeBox(100,100,100,cq.Vector(-50,-50,fronttop-100))).clean()
assert face.isValid() and len(face.Solids())==1
cq.exporters.export(face,str(O/'Face_7_Raios_CAD_Nativo.step'))
newface=mani(mesh(face))
result=barrel+hub+newface
assert str(result.status())=='Error.NoError'
res=result.to_mesh();out=trimesh.Trimesh(res.vert_properties[:,:3],res.tri_verts,process=True)
print('MALHA',len(out.faces),out.is_volume,out.is_watertight,flush=True)
assert out.is_volume and len(out.split())==1,('result split',len(out.split()))
assert abs(out.extents[2]-(fronttop-m.bounds[0,2]))<.001
out.export(O/'Roda_7_Raios_Montagem.stl')
printed=out.copy();printed.apply_translation([0,0,-printed.bounds[0,2]]);printed.export(O/'Roda_7_Raios_Impressao.stl')
# The source axis/hub must remain exactly identical in a protected check volume.
check=mani(mesh(cq.Solid.makeCylinder(8.49,19.699,cq.Vector(0,0,-30),cq.Vector(0,0,1))))
diff=((orig^check)-(result^check)).volume()+((result^check)-(orig^check)).volume()
assert diff<.005,('hub changed',diff)
# Entire material outside the nominal inner barrel remains verbatim below the front lip.
assert (barrel-result).volume()<.005
for name in ['Roda_7_Raios_Montagem.stl','Roda_7_Raios_Impressao.stl']:
 q=trimesh.load_mesh(O/name,process=True);assert q.is_volume and len(q.split())==1
report=dict(tipo='roda_T7_NIVELADA_NA_BORDA_ORIGINAL',plano_borda_original_z_mm=fronttop,plano_raios_z_mm=fronttop,plano_miolo_z_mm=fronttop,plano_tampa_z_mm=fronttop,face_plana=True,acesso_fixacao_diametro_mm=10,tampa_opcional=True,diametro_maximo_mm=float(out.extents[0]),largura_axial_mm=float(out.extents[2]),furo_eixo_mm=4,hexagono_entre_faces_mm=12.4,hexagono_fundo_z=-12.3,hexagono_entrada_z=-17.3,hub_original_preservado_raio_mm=8.49,regiao_hub_preservada_ate_z=-10.301,diferenca_volume_hub_mm3=float(diff),barrel_original_preservado=True,raios=7,furos_decorativos=5,stl_fechado=True,solidos_stl=1,cad_face_nativo=True,cad_completo_facetado_nao_fornecido=True,faces_stl=len(out.faces),volume_mm3=float(out.volume),teste_fisico=False,medidas_stl_assumidas_mm=True,coordenadas_centralizadas=True,centro_original=[-54.3,0,0],perfil_interno_corte=profile)
(O/'VALIDACAO.json').write_text(json.dumps(report,indent=2));print('RODA OK',json.dumps(report),flush=True)

# Optional flush center cover, printed separately and retained with removable adhesive.
cap=cq.Solid.makeCylinder(5.3,.6,cq.Vector(0,0,fronttop-.6),cq.Vector(0,0,1))
peg=cq.Solid.makeCylinder(4.8,1.2,cq.Vector(0,0,fronttop-1.8),cq.Vector(0,0,1)).cut(cq.Solid.makeCylinder(4.0,1.4,cq.Vector(0,0,fronttop-1.9),cq.Vector(0,0,1)))
cap=cap.fuse(peg).clean();assert cap.isValid() and len(cap.Solids())==1
cq.exporters.export(cap,str(O/'Tampa_Central_Opcional.step'))
capmesh=mesh(cap);capmesh.export(O/'Tampa_Central_Opcional_Montagem.stl')
assert (mani(capmesh)^result).volume()<.005
capprinted=capmesh.copy();capprinted.apply_transform(trimesh.transformations.rotation_matrix(np.pi,[1,0,0]));capprinted.apply_translation([0,0,-capprinted.bounds[0,2]])
capprinted.export(O/'Tampa_Central_Opcional_Impressao.stl');assert trimesh.load_mesh(O/'Tampa_Central_Opcional_Impressao.stl').is_volume
print('TAMPA OPCIONAL OK',flush=True)

# Verify the actual exported surfaces at center, spokes and original outer edge.
points=[('miolo',6,0),('raio_interno',0,15),('raio_externo',0,22),('borda_original',27.2,0)]
origins=np.array([[x,y,10] for _,x,y in points]);directions=np.tile([0,0,-1],(len(points),1))
loc,rayidx,_=out.ray.intersects_location(origins,directions,multiple_hits=True)
measurements=[]
for i,(label,x,y) in enumerate(points):
 z=float(loc[rayidx==i,2].max());assert abs(z-fronttop)<.001,(label,z,fronttop)
 measurements.append(dict(regiao=label,z_mm=z,desnivel_borda_mm=z-fronttop))
capz=float(capmesh.bounds[1,2]);assert abs(capz-fronttop)<.001
measurements.append(dict(regiao='tampa',z_mm=capz,desnivel_borda_mm=capz-fronttop))
report['verificacao_superficies_exportadas']=measurements
report['largura_original_incluindo_pontas_mm']=float(m.extents[2])
(O/'VALIDACAO.json').write_text(json.dumps(report,indent=2))
print('NIVELAMENTO MEDIDO OK',measurements,flush=True)
