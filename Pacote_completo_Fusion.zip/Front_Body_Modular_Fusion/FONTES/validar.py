import trimesh,numpy as np,manifold3d as mf,json,itertools
from pathlib import Path
R=Path(__file__).resolve().parent;D=R/'pacote/STL';parts={};records=[]
for p in sorted(D.glob('*.stl')):
 m=trimesh.load_mesh(p);s=mf.Manifold(mf.Mesh64(np.array(m.vertices,dtype=np.float64),np.array(m.faces,dtype=np.uint64)))
 a=s.to_mesh64();m=trimesh.Trimesh(a.vert_properties[:,:3],a.tri_verts,process=True)
 r=trimesh.load_mesh(p);print(p.stem,r.is_volume,len(s.decompose()),flush=True)
 assert r.is_volume and len(s.decompose())==1
 parts[p.stem]=s;records.append(dict(nome=p.stem,solidos=1,malha_fechada=True,faces=len(r.faces),volume_mm3=float(r.volume),limites_mm=r.bounds.tolist()))
pairs=[]
for (na,a),(nb,b) in itertools.combinations(parts.items(),2):
 v=(a^b).volume()
 pairs.append(dict(a=na,b=nb,volume_interferencia_mm3=v));print(na[:2],nb[:2],round(v,5),flush=True)
report=dict(unidade_assumida='mm',escala=1,pecas=records,pares=pairs,limiar_interferencia_mm3=.02,testado_fisicamente=False,testado_no_fusion=False)
(R/'pacote/validacao.json').write_text(json.dumps(report,indent=2))
