# Scripts de preparação

Python 3.12, compilador C `cc`, dependências em requirements-ambiente.txt. O Fusion não é necessário para gerar STEP. Execute na pasta FONTES, usando uma cópia de trabalho e sem substituir os arquivos finais fornecidos:

```
python analisar.py
python separar.py
python encaixes.py
python reparar_moldura.py
python validar.py
python preparar_step.py
python exportar_cad.py
python finalizar_cad.py
python previews.py
```

Os resultados de reconstrução ficam em FONTES/pacote/, e os intermediários em FONTES/step_intermediario/. O STL de entrada é ../ORIGINAL/Front_Body_V1.stl. Os cortes e pontos de encaixe estão nos scripts separar.py e encaixes.py. Ajustar essas coordenadas altera o projeto; os scripts não recuperam o histórico original do STL. A folga nominal das guias está nas caixas de encaixes.py; os pinos usam 2,0 mm de raio e os furos 2,3 mm. Teste de impressão continua necessário.

Os resultados finais deste ZIP foram validados na máquina de preparação; estes caminhos relativos foram conferidos, mas a reconstrução completa a partir desta pasta empacotada não foi repetida. A conversão opcional para F3D deve ser executada dentro do Fusion, via pasta Fusion/GerarF3D, e não neste Python.
