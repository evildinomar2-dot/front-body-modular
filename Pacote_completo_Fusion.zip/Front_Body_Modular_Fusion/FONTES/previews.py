from pathlib import Path
import numpy as np,trimesh,sys
R=Path(__file__).resolve().parent;O=R/'pacote';sys.path.insert(0,str(Path(__file__).resolve().parent))
from render_vtk import render
colors=[(.78,.25,.18),(.25,.5,.8),(.25,.5,.8),(.32,.68,.4),(.32,.68,.4),(.45,.7,.85),(.9,.65,.22),(.6,.45,.7)]
parts=[];meshes={};ex={}
offsets=[(-20,0,55),(-10,45,0),(-10,-45,0),(30,45,-15),(30,-45,-15),(0,0,40),(30,0,75),(20,0,10)]
for p,c,off in zip(sorted((O/'STL').glob('*.stl')),colors,offsets):
 m=trimesh.load_mesh(p);parts.append(dict(name=p.stem,color=c));f=np.ascontiguousarray(m.faces,dtype=np.int32);n=np.asarray(m.vertex_normals);v=np.asarray(m.vertices)
 meshes[p.stem]=(v,n,f);ex[p.stem]=(v+off,n,f)
render(parts,O/'MONTADO.png',meshes=meshes,azimuth=-145,elevation=25)
render(parts,O/'EXPLODIDO.png',meshes=ex,azimuth=-145,elevation=25)
render(parts,O/'ENCAIXES_INTERNOS.png',meshes=meshes,azimuth=-145,elevation=-30)
print('PREVIAS OK',flush=True)
