from pathlib import Path
import numpy as np,trimesh,manifold3d as mf,json
R=Path(__file__).resolve().parent;O=R/'pacote';D=O/'STL'
def mesh(s):
 a=s.to_mesh();return trimesh.Trimesh(np.asarray(a.vert_properties[:,:3]),np.asarray(a.tri_verts),process=True)
def solid(m):return mf.Manifold(mf.Mesh(np.asarray(m.vertices,dtype=np.float32),np.asarray(m.faces,dtype=np.uint32))).set_tolerance(.002)
def box(a,b):return mf.Manifold.cube(np.array(b)-a).translate(a)
def clean(s):
 s=s.simplify(.002);cs=[c for c in s.decompose() if c.volume()>.1]
 return mf.Manifold.batch_boolean(cs,mf.OpType.Add)
parts={p.stem:solid(trimesh.load_mesh(p)) for p in sorted(D.glob('*.stl'))}
names=list(parts); base=trimesh.load_mesh(R/'base_reparada.stl');log=[]
def inside_z(x,y):
 hits,_,_=base.ray.intersects_location([[x,y,200]],[[0,0,-1]],multiple_hits=True)
 z=np.sort(hits[:,2]);return float(z[-2]) if len(z)>=2 else None

def inside_y(x,z,sign):
 hits,_,_=base.ray.intersects_location([[x,0,z]],[[0,sign,0]],multiple_hits=True)
 a=sign*hits[:,1];a=a[a>0];return sign*float(min(a)) if len(a) else None

def tab(a,b,p,n,u,label):
 n=np.array(n,dtype=float);n/=np.linalg.norm(n);u=np.array(u,dtype=float);u-=n*np.dot(n,u);u/=np.linalg.norm(u);t=np.cross(u,n);mat=np.column_stack([n,t,u]);p=np.array(p,dtype=float)+u*(9. if label.startswith('teto') else 3.)
 def B(lo,hi):return box(lo,hi).transform(np.column_stack([mat,p]))
 # u=0 is inner surface, u>0 points toward cabin void.
 root=B([-6,-4,-.8],[-.1,4,3.0]);tongue=B([-1,-1.5,.5],[4.5,1.5,2.3]);receiver=B([.3,-4,-.8],[7,4,3.3]);cavity=B([-.2,-1.8,.2],[4.8,1.8,2.6])
 def attach(body,addition,point):
  if len(clean(body+addition).decompose())==1:return clean(body+addition)
  bm=mesh(body);closest,dist,idx=trimesh.proximity.closest_point(bm,[point]);q=closest[0]-bm.face_normals[idx[0]]*.7
  start=np.array(point);d=q-start;length=np.linalg.norm(d);axis=d/length
  other=np.array([0.,0.,1.]) if abs(axis[2])<.9 else np.array([0.,1.,0.]);vx=np.cross(other,axis);vx/=np.linalg.norm(vx);vy=np.cross(axis,vx)
  bridge=mf.Manifold.cylinder(length,1.8,1.8,32).transform(np.column_stack([vx,vy,axis,start]))
  return clean(body+addition+bridge)
 pa=attach(parts[a],root+tongue,p+mat@np.array([-3.,0,1.]))
 pb=attach(parts[b],receiver,p+mat@np.array([4.,0,1.]))-cavity
 # Existing panels and neighbouring supports must not invade the tongue.
 pb=clean(pb-pa)
 pa=clean(pa)
 va=len(pa.decompose());vb=len(pb.decompose());collision=(pa^pb).volume()
 log.append(dict(tipo='lingueta_interna',nome=label,a=a,b=b,ponto=p.tolist(),solidos_a=va,solidos_b=vb,interferencia_mm3=collision,folga_por_lado_mm=.3))
 if va!=1 or vb!=1: print('DESCONECTADO',log[-1],flush=True)
 parts[a]=pa;parts[b]=pb

# Para-lamas / paineis laterais: duas linguetas por lado.
for sign,fi,di in [(1,1,3),(-1,2,4)]:
 for z in [30.,55.]:
  x=-86+.12*z;y=inside_y(x,z,sign)
  tab(names[fi],names[di],[x,y,z],[1,0,-.12],[0,-sign,0],f'paralama_lateral_{sign}_{z}')
 # Painel lateral / coluna: uma lingueta sob o ombro.
 x=-18.;z=75.5;y=inside_y(x,z,sign)
 tab(names[di],names[7],[x,y,z],[0,0,1],[0,-sign,0],f'lateral_coluna_{sign}')
 # Calha central / para-lama: proximidade da borda lateral do capot.
 x=-102.;y=sign*78.;z=inside_z(x,y)
 tab(names[7],names[fi],[x,y,z],[0,sign,0],[0,0,-1],f'calha_paralama_{sign}')
 # Painel parabrisa / moldura, encaixe interno lateral.
 x=-52.;y=sign*68.;z=inside_z(x,y)
 tab(names[5],names[7],[x,y,z],[0,sign,0],[1,0,-1],f'parabrisa_moldura_{sign}')
 # Teto / coluna, junta frontal.
 x=-30.;y=sign*55.;z=inside_z(x,y)
 tab(names[7],names[6],[x,y,z],[1,0,0],[0,0,-1],f'teto_coluna_{sign}')
 # Capo removivel: pinos verticais e suportes nos para-lamas.
 for x in [-185.,-140.]:
  yc=sign*72.;zi=inside_z(x,yc)
  zf=min(inside_z(x,sign*q) for q in [79.5,81.,83.])-1.
  lo,hi=sorted([sign*68.,sign*84.]);shelf=box([x-4,lo,zf-2.8],[x+4,hi,zf])
  lo2,hi2=sorted([sign*79.,sign*84.]);za=min(inside_z(x,sign*q) for q in [79.5,81.,83.])+.6
  anchor=box([x-4,lo2,zf-2.8],[x+4,hi2,za])
  hole=mf.Manifold.cylinder(15,2.3,2.3,48).translate([x,yc,zf-5])
  support=(shelf+anchor)-hole
  peg=mf.Manifold.cylinder(zi+.65-(zf-2.4),2.,2.,48).translate([x,yc,zf-2.4])
  parts[names[0]]=clean(parts[names[0]]+peg);parts[names[fi]]=clean(parts[names[fi]]+support)
  log.append(dict(tipo='pino_capo',ponto=[x,yc,zf],diametro_pino_mm=4.,diametro_furo_mm=4.6,solidos_capo=len(parts[names[0]].decompose()),solidos_paralama=len(parts[names[fi]].decompose())))
  print('PINO',log[-1],flush=True)

(O/'encaixes.json').write_text(json.dumps(log,indent=2))
for name,s in parts.items():
 m=mesh(s);m.export(D/f'{name}.stl');print('FINAL',name,s.status(),len(s.decompose()),m.is_volume,len(m.faces),flush=True)
np.savez(R/'estado_encaixes.npz',**{n:mesh(s).vertices for n,s in parts.items()})
