from pathlib import Path
import trimesh,numpy as np,manifold3d as mf
D=Path(__file__).resolve().parent/'pacote/STL'
def get(n):
 m=trimesh.load_mesh(next(D.glob(n+'*.stl')));return mf.Manifold(mf.Mesh(np.array(m.vertices,dtype=np.float32),np.array(m.faces,dtype=np.uint32)))
import pymeshfix
s=get('08')-get('01')-get('06')
s=max(s.decompose(),key=lambda x:x.volume()).simplify(.005)
a=s.to_mesh64();m=trimesh.Trimesh(a.vert_properties[:,:3],a.tri_verts,process=True)
print('before',m.is_volume,len(m.faces),flush=True)
fix=pymeshfix.MeshFix(m.vertices,m.faces);fix.repair(joincomp=False,remove_smallest_components=True)
v,f=fix.points,fix.faces
m=trimesh.Trimesh(v,f,process=True);print('fixed',m.is_volume,len(m.faces),flush=True)
assert m.is_volume
path=next(D.glob('08*.stl'))
with path.open('w') as stream:
 stream.write('solid moldura\n')
 for normal,tri in zip(m.face_normals,m.triangles):
  stream.write('facet normal '+' '.join(format(float(x),'.17g') for x in normal)+'\nouter loop\n')
  for point in tri:stream.write('vertex '+' '.join(format(float(x),'.17g') for x in point)+'\n')
  stream.write('endloop\nendfacet\n')
 stream.write('endsolid moldura\n')
r=trimesh.load_mesh(next(D.glob('08*.stl')));print('roundtrip',r.is_volume,flush=True)
assert r.is_volume
