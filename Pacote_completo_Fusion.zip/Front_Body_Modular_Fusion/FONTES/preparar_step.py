import trimesh,numpy as np,manifold3d as mf,json,itertools
from pathlib import Path
R=Path(__file__).resolve().parent;D=R/'step_intermediario';D.mkdir(exist_ok=True);ss=[];report=[]
for p in sorted((R/'pacote/STL').glob('*.stl')):
 m=trimesh.load_mesh(p);s=mf.Manifold(mf.Mesh64(np.array(m.vertices,dtype=np.float64),np.array(m.faces,dtype=np.uint64))).simplify(.1)
 clipped=[]
 for name,prev in ss:
  v=(s^prev).volume()
  if v>.02:
   s=s-prev;clipped.append(dict(com=name,volume_retirado_mm3=v))
 s=s.simplify(.001);cs=s.decompose();tiny=[c.volume() for c in cs if c.volume()<.02];s=mf.Manifold.batch_boolean([c for c in cs if c.volume()>=.02],mf.OpType.Add)
 assert len(s.decompose())==1,(p.stem,len(s.decompose()))
 a=s.to_mesh64();np.savez(D/(p.stem+'.npz'),v=a.vert_properties[:,:3],f=a.tri_verts)
 ss.append((p.stem,s));report.append(dict(nome=p.stem,faces=s.num_tri(),simplificacao_mm=.1,compatibilizacao=clipped,fragmentos_removidos_mm3=tiny));print(p.stem,s.num_tri(),clipped,flush=True)
pairs=[]
for (na,a),(nb,b) in itertools.combinations(ss,2):
 v=(a^b).volume();pairs.append(dict(a=na,b=nb,volume_interferencia_mm3=v));assert v<.02,(na,nb,v)
(R/'pacote/validacao_step_geometria.json').write_text(json.dumps(dict(pecas=report,pares=pairs,limiar_mm3=.02),indent=2))
