from pathlib import Path
import numpy as np,trimesh,manifold3d as mf,pymeshfix,cadquery as cq
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeVertex,BRepBuilderAPI_MakeEdge,BRepBuilderAPI_MakeWire,BRepBuilderAPI_MakeFace
from OCP.BRep import BRep_Builder
from OCP.TopoDS import TopoDS,TopoDS_Shell
from OCP.gp import gp_Pnt
R=Path(__file__).resolve().parent;O=R/'pacote';m=trimesh.load_mesh(O/'STL/08_moldura_calha_colunas.stl')
s=mf.Manifold(mf.Mesh64(np.array(m.vertices,dtype=np.float64),np.array(m.faces,dtype=np.uint64))).simplify(.08)
others=[]
for source in sorted((R/'step_intermediario').glob('*.npz')):
 if source.stem.startswith('08'):continue
 a=np.load(source);others.append((source.stem,mf.Manifold(mf.Mesh64(np.asarray(a['v'],dtype=np.float64),np.asarray(a['f'],dtype=np.uint64)))))
for name,other in others:
 if (s^other).volume()>.001:s=s-other
s=s.simplify(.001);a=s.to_mesh64();q=trimesh.Trimesh(a.vert_properties[:,:3],a.tri_verts,process=True);q.merge_vertices(digits_vertex=5);q.update_faces(q.nondegenerate_faces(height=1e-6));q.remove_unreferenced_vertices()
print('BEFORE',q.volume,len(q.faces),flush=True)
fix=pymeshfix.MeshFix(q.vertices,q.faces);fix.repair(joincomp=True,remove_smallest_components=False)
q=trimesh.Trimesh(fix.points,fix.faces,process=True);print('AFTER',q.volume,len(q.faces),q.is_volume,len(q.split()),flush=True)
assert .95*m.volume<q.volume<1.05*m.volume
q.export(R/'moldura_cad_reparada.ply')
s=mf.Manifold(mf.Mesh64(np.array(q.vertices,dtype=np.float64),np.array(q.faces,dtype=np.uint64)));print('CHECK',s.status(),len(s.decompose()),flush=True)
for name,other in others:print('PAIR',name,(s^other).volume(),flush=True)
v=q.vertices;f=q.faces
vertices=[BRepBuilderAPI_MakeVertex(gp_Pnt(*map(float,p))).Vertex() for p in v];edges={};builder=BRep_Builder();shell=TopoDS_Shell();builder.MakeShell(shell)
for tri in f:
 wire=BRepBuilderAPI_MakeWire()
 for start,end in zip(tri,np.roll(tri,-1)):
  key=tuple(sorted([int(start),int(end)]))
  if key not in edges:edges[key]=BRepBuilderAPI_MakeEdge(vertices[key[0]],vertices[key[1]]).Edge()
  wire.Add(edges[key] if start<end else TopoDS.Edge_s(edges[key].Reversed()))
 builder.Add(shell,BRepBuilderAPI_MakeFace(wire.Wire()).Face())
shell.Closed(True);body=cq.Solid.makeSolid(cq.Shell(shell)).clean().fix();print('CAD',body.isValid(),len(body.Solids()),body.Volume(),flush=True)
assert body.isValid() and len(body.Solids())==1
out=O/'STEP/08_moldura_calha_colunas.step';cq.exporters.export(body,str(out));test=cq.importers.importStep(str(out)).val();assert test.isValid() and len(test.Solids())==1
np.savez(R/'step_intermediario/08_moldura_calha_colunas.npz',v=v,f=f);print('SUCCESS COMPLETE FRAME',flush=True)
