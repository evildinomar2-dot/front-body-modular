import trimesh,numpy as np,manifold3d as mf,cadquery as cq,json,time
from pathlib import Path
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakePolygon,BRepBuilderAPI_MakeFace,BRepBuilderAPI_Sewing
from OCP.gp import gp_Pnt
R=Path(__file__).resolve().parent;O=R/'pacote';(O/'STEP').mkdir(exist_ok=True)
colors=[(.78,.25,.18),(.25,.5,.8),(.25,.5,.8),(.32,.68,.4),(.32,.68,.4),(.45,.7,.85),(.9,.65,.22),(.6,.45,.7)]
assembly=cq.Assembly(name='FRONT_BODY_V1_MODULAR');report=[]
for p,color in zip(sorted((O/'STL').glob('*.stl')),colors):
 data=np.load(R/'step_intermediario'/(p.stem+'.npz'));v=data['v'];f=data['f']
 if p.stem.startswith('08'):
  import subprocess,sys
  subprocess.run([sys.executable,str(R/'reconstruir_moldura_cad.py')],check=True)
  subprocess.run([sys.executable,str(R/'folga_final_moldura.py')],check=True)
  body=cq.importers.importStep(str(O/'STEP'/(p.stem+'.step'))).val()
  assert body.isValid() and len(body.Solids())==1
  assembly.add(body,name=p.stem,color=cq.Color(*color))
  report.append(dict(nome=p.stem,faces_step=len(body.Faces()),solido_valido=True,reimportacao_step_valida=True,simplificacao_adicional_mm=.1))
  continue
 print('CAD',p.stem,len(f),'faces',flush=True)
 sew=BRepBuilderAPI_Sewing(1e-7 if p.stem.startswith('08') else 1e-5,True,True,True,False)
 for tri in f:
  poly=BRepBuilderAPI_MakePolygon()
  for point in v[tri]:poly.Add(gp_Pnt(*map(float,point)))
  poly.Close();face=BRepBuilderAPI_MakeFace(poly.Wire()).Face();sew.Add(face)
 sew.Perform();shape=cq.Shape.cast(sew.SewedShape());shells=shape.Shells()
 assert len(shells)==1,(p.stem,len(shells))
 body=cq.Solid.makeSolid(shells[0]);body=body.fix()
 assert body.isValid() and len(body.Solids())==1,(p.stem,'invalid')
 out=O/'STEP'/f'{p.stem}.step';cq.exporters.export(body,str(out))
 test=cq.importers.importStep(str(out)).val()
 assert test.isValid() and len(test.Solids())==1
 assembly.add(body,name=p.stem,color=cq.Color(*color))
 report.append(dict(nome=p.stem,faces_step=len(body.Faces()),solido_valido=True,reimportacao_step_valida=True,simplificacao_adicional_mm=.1))
 print('CAD OK',p.stem,flush=True)
(O/'validacao_step.json').write_text(json.dumps(report,indent=2))
assembly.export(str(O/'MONTAGEM_MODULAR.step'))
print('ASSEMBLY EXPORT OK',flush=True)
check=cq.importers.importStep(str(O/'MONTAGEM_MODULAR.step')).val()
assert check.isValid() and len(check.Solids())==8
print('ASSEMBLY REIMPORT 8 SOLIDS OK',flush=True)
