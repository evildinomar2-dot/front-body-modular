from pathlib import Path
import cadquery as cq,json,numpy as np,manifold3d as mf,itertools
R=Path(__file__).resolve().parent;O=R/'pacote';colors=[(.78,.25,.18),(.25,.5,.8),(.25,.5,.8),(.32,.68,.4),(.32,.68,.4),(.45,.7,.85),(.9,.65,.22),(.6,.45,.7)]
assembly=cq.Assembly(name='FRONT_BODY_V1_MODULAR');report=[];parts=[]
for p,c in zip(sorted((O/'STEP').glob('*.step')),colors):
 s=cq.importers.importStep(str(p)).val();assert s.isValid() and len(s.Solids())==1
 assembly.add(s,name=p.stem,color=cq.Color(*c));report.append(dict(nome=p.stem,faces_step=len(s.Faces()),solido_valido=True,reimportacao_step_valida=True))
 a=np.load(R/'step_intermediario'/(p.stem+'.npz'));parts.append((p.stem,mf.Manifold(mf.Mesh64(np.asarray(a['v'],dtype=np.float64),np.asarray(a['f'],dtype=np.uint64)))))
 print('REIMPORTADO',p.stem,flush=True)
pairs=[]
for (na,a),(nb,b) in itertools.combinations(parts,2):
 v=(a^b).volume();pairs.append(dict(a=na,b=nb,volume_interferencia_mm3=v));print(na[:2],nb[:2],round(v,6),flush=True)
 assert v<.02,(na,nb,v)
(O/'validacao_step_pares_final.json').write_text(json.dumps(dict(pares=pairs,limiar_mm3=.02),indent=2))
(O/'validacao_step.json').write_text(json.dumps(report,indent=2))
assembly.export(str(O/'MONTAGEM_MODULAR.step'));print('MONTAGEM EXPORTADA',flush=True)
s=cq.importers.importStep(str(O/'MONTAGEM_MODULAR.step')).val();assert s.isValid() and len(s.Solids())==8
(O/'validacao_montagem_step.json').write_text(json.dumps(dict(solidos=8,valido=True,reimportacao_valida=True),indent=2));print('MONTAGEM VALIDA:8 SOLIDOS',flush=True)
