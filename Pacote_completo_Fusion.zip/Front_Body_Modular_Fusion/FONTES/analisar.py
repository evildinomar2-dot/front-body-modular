import trimesh,numpy as np,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
m=trimesh.load_mesh(str(Path(__file__).resolve().parent.parent/'ORIGINAL/Front_Body_V1.stl'))
m=max(m.split(only_watertight=False),key=lambda s:len(s.faces))
t=np.eye(4);t[:3,:3]=[[0,0,-1],[1,0,0],[0,-1,0]]
m.apply_transform(t);m.export(ROOT/'base_reparada.stl')
print('reparada',len(m.faces),m.is_volume,m.bounds,flush=True)
sys.path.insert(0,str(Path(__file__).resolve().parent))
from render_vtk import render
v=np.asarray(m.vertices);f=np.ascontiguousarray(m.faces,dtype=np.int32);n=np.asarray(m.vertex_normals)
for az,el,label in [(-145,25,'original_perspectiva'),(-90,90,'original_superior'),(-90,0,'original_lateral'),(180,0,'original_frontal')]:
 render([dict(name='modelo',color=(.65,.69,.75))],ROOT/f'{label}.png',meshes={'modelo':(v,n,f)},azimuth=az,elevation=el,size=(1600,1100))
