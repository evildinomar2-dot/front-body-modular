from pathlib import Path
import numpy as np,manifold3d as mf,trimesh,cadquery as cq,json
R=Path(__file__).resolve().parent;O=R/'pacote';D=R/'step_intermediario'
a=np.load(D/'08_moldura_calha_colunas.npz');s=mf.Manifold(mf.Mesh64(np.asarray(a['v'],dtype=np.float64),np.asarray(a['f'],dtype=np.uint64)))
a=np.load(D/'01_capo.npz');h=mf.Manifold(mf.Mesh64(np.asarray(a['v'],dtype=np.float64),np.asarray(a['f'],dtype=np.uint64)))
tools=[];cuts=[]
for c in (s^h).decompose():
 if c.volume()<.01:continue
 v=c.to_mesh64().vert_properties[:,:3];lo=v.min(0)-.05;hi=v.max(0)+.05
 tools.append(cq.Solid.makeBox(*map(float,hi-lo),cq.Vector(*map(float,lo))))
 cuts.append(dict(min=lo.tolist(),max=hi.tolist(),interferencia_original_mm3=c.volume()))
body=cq.importers.importStep(str(O/'STEP/08_moldura_calha_colunas.step')).val()
print('CUTS',len(tools),flush=True)
for tool in tools:
 body=body.cut(tool,tol=1e-6).clean().fix();print('CUT',body.isValid(),len(body.Solids()),body.Volume(),flush=True)
 assert body.isValid() and len(body.Solids())==1
cq.exporters.export(body,str(O/'STEP/08_moldura_calha_colunas.step'))
check=cq.importers.importStep(str(O/'STEP/08_moldura_calha_colunas.step')).val();assert check.isValid() and len(check.Solids())==1
for cut in cuts:
 lo=np.array(cut['min']);hi=np.array(cut['max']);s=s-mf.Manifold.cube(hi-lo).translate(lo)
print('VOLUME CHECK',s.volume(),check.Volume(),abs(s.volume()-check.Volume()),flush=True)
assert abs(s.volume()-check.Volume())<.02 and len(s.decompose())==1
a=s.to_mesh64();np.savez(D/'08_moldura_calha_colunas.npz',v=a.vert_properties[:,:3],f=a.tri_verts)
(O/'ajustes_folga_moldura.json').write_text(json.dumps(cuts,indent=2));print('FRAME FINAL OK',flush=True)
