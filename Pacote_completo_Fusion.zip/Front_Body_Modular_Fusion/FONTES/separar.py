from pathlib import Path
import numpy as np, trimesh, manifold3d as mf, json,sys
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'pacote';(OUT/'STL').mkdir(parents=True,exist_ok=True)
def box(lo,hi):return mf.Manifold.cube(np.array(hi)-lo).translate(lo)
def tomesh(s):
 a=s.to_mesh();return trimesh.Trimesh(np.array(a.vert_properties[:,:3]),np.array(a.tri_verts),process=True)
m=trimesh.load_mesh(ROOT/'base_reparada.stl')
s=mf.Manifold(mf.Mesh(np.asarray(m.vertices,dtype=np.float32),np.asarray(m.faces,dtype=np.uint32)))
s=s.set_tolerance(.002)
print('base',s.status(),s.volume(),flush=True)
# Capo: contorno traseiro curvo e linhas laterais existentes.
y=np.linspace(-78,78,101);back=-114+24*(abs(y)/78)**4
poly=[[-270,-76],[-200,-76],[-145,-78]]+[[float(x),float(a)] for x,a in zip(back,y)]+[[-145,78],[-200,76],[-270,76]]
hoodmask=mf.CrossSection([np.array(poly)]).extrude(180) ^ box([-280,-120,50],[30,120,180])
hood=s^hoodmask;rest=s-hoodmask
# Junta para-lama/porta segue inclinacao da linha existente.
rear,front=rest.split_by_plane([1,0,-.12],-86/np.sqrt(1+.12**2))
# split_by_plane offset is distance along normalized normal
cowlmask=box([-120,-78,50],[-73,78,100])-hoodmask
cowl=front^cowlmask
front=front-cowlmask
rear=rear+cowl
left,right=front.split_by_plane([0,1,0],0)
pieces={'01_capo':hood,'02_paralama_Ypositivo':left,'03_paralama_Ynegativo':right}
# Portas / paineis laterais, corte no ombro horizontal.
for sign,name in [(1,'04_painel_lateral_Ypositivo'),(-1,'05_painel_lateral_Ynegativo')]:
 mask=box([-90,70 if sign>0 else -120,-10],[20,120 if sign>0 else -70,75.5])
 p=rear^mask;rear=rear-mask;pieces[name]=p
# Parabrisa: painel central, separado da moldura e da calha inferior.
mask=box([-78,-68,69],[-31,68,113])
pieces['06_painel_parabrisa']=rear^mask;rear=rear-mask
mask=box([-30,-120,107],[20,120,160])
pieces['07_teto']=rear^mask;rear=rear-mask
pieces['08_moldura_calha_colunas']=rear
records=[]
for name,p in pieces.items():
 p=p.simplify(.002)
 chunks=[c for c in p.decompose() if c.volume()>.01]
 p=mf.Manifold.batch_boolean(chunks,mf.OpType.Add)
 pieces[name]=p
 mesh=tomesh(p);mesh.export(OUT/'STL'/f'{name}.stl')
 rec=dict(nome=name,faces=len(mesh.faces),volume=p.volume(),solidos=len(p.decompose()),valido=mesh.is_volume,limites=mesh.bounds.tolist());records.append(rec);print(rec,flush=True)
(OUT/'cortes.json').write_text(json.dumps(records,indent=2))
sys.path.insert(0,str(Path(__file__).resolve().parent));from render_vtk import render
colors=[(.78,.25,.18),(.25,.5,.8),(.25,.5,.8),(.32,.68,.4),(.32,.68,.4),(.45,.7,.85),(.9,.65,.22),(.6,.45,.7)]
parts=[];meshes={}
for (name,p),color in zip(pieces.items(),colors):
 a=tomesh(p);parts.append(dict(name=name,color=color));meshes[name]=(np.asarray(a.vertices),np.asarray(a.vertex_normals),np.ascontiguousarray(a.faces,dtype=np.int32))
render(parts,OUT/'SEPARACAO.png',meshes=meshes,azimuth=-145,elevation=27)
