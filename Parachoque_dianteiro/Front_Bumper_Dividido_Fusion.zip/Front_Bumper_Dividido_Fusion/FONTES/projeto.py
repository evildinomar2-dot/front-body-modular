from pathlib import Path
import numpy as np,trimesh,manifold3d as mf,cadquery as cq,json,itertools
R=Path(__file__).resolve().parent;O=R/'pacote'
for folder in ['STL_MONTAGEM','STL_IMPRESSAO','STEP','FONTES','ORIGINAL']:(O/folder).mkdir(parents=True,exist_ok=True)
raw=trimesh.load_mesh(R/'base_normalizada.stl')
def S(m):return mf.Manifold(mf.Mesh64(np.array(m.vertices,dtype=np.float64,order='C'),np.array(m.faces,dtype=np.uint64,order='C')))
def M(s):
 a=s.to_mesh64();return trimesh.Trimesh(a.vert_properties[:,:3],a.tri_verts,process=True)
def B(lo,hi):return mf.Manifold.cube(np.array(hi)-lo).translate(lo)
def export_ascii(m,path):
 with path.open('w') as f:
  f.write('solid front_bumper\n')
  for normal,tri in zip(m.face_normals,m.triangles):
   f.write('facet normal '+' '.join(format(float(x),'.17g') for x in normal)+'\nouter loop\n')
   for p in tri:f.write('vertex '+' '.join(format(float(x),'.17g') for x in p)+'\n')
   f.write('endloop\nendfacet\n')
  f.write('endsolid front_bumper\n')

source=S(raw);cad_source=source.simplify(.02)
print('BASE',source.num_tri(),cad_source.num_tri(),source.volume(),flush=True)
# Coordinates are depth X, transverse Y, height Z. Keys run along transverse Y.
specs=[dict(nome='03_chaveta_A_faixa_central',x=-31.5,z=48.5,w=2.8,h=4.,length=14.),dict(nome='04_chaveta_B_parede_frontal',x=-62.,z=38.2,w=1.4,h=3.,length=12.),dict(nome='05_chaveta_C_parede_traseira',x=-6.6,z=39.8,w=1.2,h=3.,length=12.)]
clearance=.20;end_clearance=.30;pockets=[];keys={};key_cad={};skin=[]
for spec in specs:
 x,z,w,h,L=[spec[k] for k in ['x','z','w','h','length']]
 lo=np.array([x-w/2-clearance,-L/2-end_clearance,z-h/2-clearance]);hi=np.array([x+w/2+clearance,L/2+end_clearance,z+h/2+clearance]);pocket=B(lo,hi)
 outside=(pocket-source).volume();assert abs(outside)<1e-7,(spec['nome'],outside)
 assert abs((pocket-cad_source).volume())<1e-7
 # Minimum original-wall cover at a regular grid on all pocket faces.
 samples=[]
 for axis in range(3):
  a,b=[i for i in range(3) if i!=axis]
  for boundary in [lo[axis],hi[axis]]:
   for u in np.linspace(lo[a],hi[a],7):
    for v in np.linspace(lo[b],hi[b],7):
     q=np.zeros(3);q[axis]=boundary;q[a]=u;q[b]=v;samples.append(q)
 dist=trimesh.proximity.signed_distance(raw,np.asarray(samples));minimum=float(dist.min());assert minimum>.65,(spec['nome'],minimum)
 skin.append(dict(nome=spec['nome'],cobertura_minima_amostrada_mm=minimum,amostras=len(samples),volume_alojamento_fora_original_mm3=outside));print('POCKET',spec['nome'],'skin',minimum,flush=True)
 solid=cq.Solid.makeBox(w,L,h,cq.Vector(x-w/2,-L/2,z-h/2));solid=cq.Workplane().newObject([solid]).edges().chamfer(.15).val();assert solid.isValid()
 vv,ff=solid.tessellate(.001,.1);mesh=trimesh.Trimesh(np.array([p.toTuple() for p in vv]),np.array(ff),process=True);assert mesh.is_volume
 key=S(mesh);assert abs((key-source).volume())<1e-7
 keys[spec['nome']]=key;key_cad[spec['nome']]=solid;pockets.append(pocket);spec.update(folga_lateral_por_face_mm=clearance,folga_axial_por_extremo_mm=end_clearance,chanfro_mm=.15,alojamento_min=lo.tolist(),alojamento_max=hi.tolist())

pocket=mf.Manifold.batch_boolean(pockets,mf.OpType.Add)
left,right=(source-pocket).split_by_plane([0,1,0],0)
cleft,cright=(cad_source-pocket).split_by_plane([0,1,0],0)
parts={'01_metade_Ypositivo':left,'02_metade_Ynegativo':right,**keys};cadparts={'01_metade_Ypositivo':cleft,'02_metade_Ynegativo':cright}
records=[]
for name,s in parts.items():
 mesh=M(s)
 if not mesh.is_volume:s=s.simplify(.000001);mesh=M(s)
 assert mesh.is_volume and len(s.decompose())==1,(name,'invalid solid')
 export_ascii(mesh,O/'STL_MONTAGEM'/(name+'.stl'))
 # Each half is on its cut face; keys lie on the largest useful face.
 printed=mesh.copy();transform=np.eye(4)
 if name.startswith('01'):transform[:3,:3]=[[1,0,0],[0,0,-1],[0,1,0]]
 elif name.startswith('02'):transform[:3,:3]=[[1,0,0],[0,0,1],[0,-1,0]]
 else:transform[:3,:3]=[[0,0,1],[0,1,0],[-1,0,0]]
 printed.apply_transform(transform);shift=np.array([-printed.bounds[:,0].mean(),-printed.bounds[:,1].mean(),-printed.bounds[0,2]]);printed.apply_translation(shift);export_ascii(printed,O/'STL_IMPRESSAO'/(name+'.stl'))
 reopened=trimesh.load_mesh(O/'STL_MONTAGEM'/(name+'.stl'));check_print=trimesh.load_mesh(O/'STL_IMPRESSAO'/(name+'.stl'));assert reopened.is_volume and check_print.is_volume
 assert abs(printed.volume-mesh.volume)<.001
 records.append(dict(nome=name,solidos=1,malha_fechada=True,faces=len(mesh.faces),volume_mm3=s.volume(),dimensoes_montagem_mm=mesh.extents.tolist(),dimensoes_impressao_mm=printed.extents.tolist(),matriz_impressao=transform.tolist(),translacao_impressao=shift.tolist()))
 np.savez(R/(name+'.npz'),v=mesh.vertices,f=mesh.faces)
 print('STL',name,mesh.extents,printed.extents,flush=True)

# Full assembly must fit inside the original material, so no key/strap can enter the grille void.
assembly=mf.Manifold.batch_boolean(list(parts.values()),mf.OpType.Add)
added=(assembly-source).volume();assert abs(added)<.00001
pairs=[]
for (na,a),(nb,b) in itertools.combinations(parts.items(),2):
 v=max(abs((a^b).volume()),abs((b^a).volume()));assert v<.0001,(na,nb,v);pairs.append(dict(a=na,b=nb,interferencia_mm3=v))
# During lateral insertion the keys must remain free inside the matching pocket.
insertion=[]
for sign,half in [(1,left),(-1,right)]:
 for delta in [.25,1.,3.,6.,8.]:
  half_shift=half.translate([0,sign*delta,0]);v=max(abs((half_shift^k).volume()) for k in keys.values());assert v<.0001,(sign,delta,v);insertion.append(dict(lado=sign,afastamento_mm=delta,interferencia_chavetas_mm3=v))

cad_data={}
for name,s in cadparts.items():
 m=M(s);assert m.is_volume and len(s.decompose())==1
 a=s.to_mesh64();np.savez(R/('CAD_'+name+'.npz'),v=m.vertices,f=m.faces);cad_data[name]=s
for (na,a),(nb,b) in itertools.combinations({**cad_data,**keys}.items(),2):assert max(abs((a^b).volume()),abs((b^a).volume()))<.0001
for name,body in key_cad.items():cq.exporters.export(body,str(O/'STEP'/(name+'.step')))
(O/'dimensoes_chavetas.json').write_text(json.dumps(specs,indent=2))
(O/'validacao.json').write_text(json.dumps(dict(unidade_assumida='mm',escala=1,pecas=records,cobertura_paredes=skin,pares=pairs,volume_adicionado_fora_original_mm3=added,testes_insercao=insertion,testado_fisicamente=False,testado_no_fusion=False,simplificacao_adicional_cad_mm=.02),indent=2))
print('GEOMETRIA VALIDADA:2 METADES + 3 CHAVETAS; VAOS PRESERVADOS',flush=True)
