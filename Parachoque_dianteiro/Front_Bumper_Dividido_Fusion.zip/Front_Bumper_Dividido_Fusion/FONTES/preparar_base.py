from pathlib import Path
import numpy as np,trimesh
R=Path(__file__).resolve().parent
m=trimesh.load_mesh(R.parent/'ORIGINAL/Front_Bumper_V1.stl');assert m.is_volume
transform=np.eye(4);transform[:3,:3]=[[0,0,-1],[1,0,0],[0,-1,0]];m.apply_transform(transform)
mid=float(m.bounds[:,1].mean());floor=float(m.bounds[0,2]);m.apply_translation([0,-mid,-floor]);m.export(R/'base_normalizada.stl')
s=m.section(plane_origin=[0,0,0],plane_normal=[0,1,0]);np.savez(R/'seccao.npz',**{f'loop{i}':p[:,[0,2]] for i,p in enumerate(s.discrete)})
print('Base orientada sem reescala e secao central preparadas.')
