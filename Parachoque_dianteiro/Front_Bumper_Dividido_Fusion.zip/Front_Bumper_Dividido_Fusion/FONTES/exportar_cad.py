from pathlib import Path
import numpy as np,trimesh,cadquery as cq,json
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeVertex,BRepBuilderAPI_MakeEdge,BRepBuilderAPI_MakeWire,BRepBuilderAPI_MakeFace
from OCP.BRep import BRep_Builder
from OCP.TopoDS import TopoDS,TopoDS_Shell
from OCP.gp import gp_Pnt
R=Path(__file__).resolve().parent;O=R/'pacote';assembly=cq.Assembly(name='PARACHOQUE_DIANTEIRO_DIVIDIDO');records=[]
colors=[(.25,.5,.8),(.8,.35,.2),(.9,.7,.15),(.35,.75,.4),(.65,.35,.8)]
for i,p in enumerate(sorted(R.glob('CAD_0*.npz'))):
 name=p.stem.removeprefix('CAD_');data=np.load(p);m=trimesh.Trimesh(data['v'],data['f'],process=True);assert m.is_volume
 v=m.vertices;f=m.faces;vertices=[BRepBuilderAPI_MakeVertex(gp_Pnt(*map(float,p))).Vertex() for p in v];edges={};builder=BRep_Builder();shell=TopoDS_Shell();builder.MakeShell(shell)
 print('CAD',name,len(f),flush=True)
 for tri in f:
  wire=BRepBuilderAPI_MakeWire()
  for start,end in zip(tri,np.roll(tri,-1)):
   key=tuple(sorted([int(start),int(end)]))
   if key not in edges:edges[key]=BRepBuilderAPI_MakeEdge(vertices[key[0]],vertices[key[1]]).Edge()
   wire.Add(edges[key] if start<end else TopoDS.Edge_s(edges[key].Reversed()))
  builder.Add(shell,BRepBuilderAPI_MakeFace(wire.Wire()).Face())
 shell.Closed(True);raw=cq.Solid.makeSolid(cq.Shell(shell));body=raw
 if not body.isValid():body=raw.clean().fix()
 assert body.isValid() and len(body.Solids())==1,(name,'invalid CAD')
 assert abs(body.Volume()-m.volume)<.02
 out=O/'STEP'/(name+'.step');cq.exporters.export(body,str(out));q=cq.importers.importStep(str(out)).val();assert q.isValid() and len(q.Solids())==1
 assert abs(q.Volume()-m.volume)<.02
 records.append(dict(nome=name,solidos=1,valido=True,reimportado=True,volume_mm3=q.Volume(),diferenca_volume_malha_cad_mm3=abs(q.Volume()-m.volume),faces=len(q.Faces())))
 assembly.add(q,name=name,color=cq.Color(*colors[i]));print('STEP OK',name,flush=True)
for i,p in enumerate(sorted((O/'STEP').glob('0[345]*.step')),2):
 q=cq.importers.importStep(str(p)).val();assert q.isValid() and len(q.Solids())==1
 records.append(dict(nome=p.stem,solidos=1,valido=True,reimportado=True,volume_mm3=q.Volume(),faces=len(q.Faces()),tipo='chaveta_analitica_chanfrada'))
 assembly.add(q,name=p.stem,color=cq.Color(*colors[i]))
assert len(records)==5
(O/'validacao_step.json').write_text(json.dumps(records,indent=2))
assembly.export(str(O/'MONTAGEM_PARACHOQUE_DIVIDIDO.step'));print('MONTAGEM EXPORTADA',flush=True)
q=cq.importers.importStep(str(O/'MONTAGEM_PARACHOQUE_DIVIDIDO.step')).val();assert q.isValid() and len(q.Solids())==5
(O/'validacao_montagem_step.json').write_text(json.dumps(dict(solidos=5,valido=True,reimportado=True),indent=2));print('MONTAGEM REIMPORTADA:5 SOLIDOS VALIDOS',flush=True)
