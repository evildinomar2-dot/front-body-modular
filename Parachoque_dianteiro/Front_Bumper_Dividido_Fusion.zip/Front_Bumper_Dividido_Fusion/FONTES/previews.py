from pathlib import Path
import trimesh,numpy as np,json,vtk
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray,vtk_to_numpy
from render_vtk import render
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Polygon
R=Path(__file__).resolve().parent;O=R/'pacote';colors=[(.25,.5,.8),(.8,.35,.2),(.9,.7,.15),(.35,.75,.4),(.65,.35,.8)]
def render_mesh(m):
 poly=vtk.vtkPolyData();pts=vtk.vtkPoints();pts.SetData(numpy_to_vtk(np.asarray(m.vertices),deep=True));poly.SetPoints(pts)
 cells=vtk.vtkCellArray();packed=np.column_stack((np.full(len(m.faces),3,dtype=np.int64),m.faces)).ravel();cells.SetCells(len(m.faces),numpy_to_vtkIdTypeArray(packed,deep=True));poly.SetPolys(cells)
 normals=vtk.vtkPolyDataNormals();normals.SetInputData(poly);normals.ConsistencyOn();normals.AutoOrientNormalsOn();normals.SplittingOn();normals.SetFeatureAngle(35);normals.ComputePointNormalsOn();normals.Update();a=normals.GetOutput()
 return vtk_to_numpy(a.GetPoints().GetData()),vtk_to_numpy(a.GetPointData().GetNormals()),np.ascontiguousarray(vtk_to_numpy(a.GetPolys().GetData()).reshape(-1,4)[:,1:],dtype=np.int32)
parts=[];meshes={};exploded={}
for i,(p,col) in enumerate(zip(sorted((O/'STL_MONTAGEM').glob('*.stl')),colors)):
 m=trimesh.load_mesh(p);v,n,f=render_mesh(m);parts.append(dict(name=p.stem,color=col));meshes[p.stem]=(v,n,f)
 shift=np.array([0,20 if i==0 else -20,0]) if i<2 else np.zeros(3)
 exploded[p.stem]=(v+shift,n,f)
for label,ms,az,el in [('MONTADO',meshes,-145,25),('EXPLODIDO',exploded,-145,25),('VISTA_INTERNA',exploded,35,20)]:render(parts,O/(label+'.png'),meshes=ms,azimuth=az,elevation=el,size=(1600,1000))

loops=np.load(R/'seccao.npz');specs=json.loads((O/'dimensoes_chavetas.json').read_text());fig=plt.figure(figsize=(14,9),layout='constrained');gs=fig.add_gridspec(2,3,height_ratios=[1.35,1]);ax=fig.add_subplot(gs[0,:]);axes=[fig.add_subplot(gs[1,i]) for i in range(3)]
for panel in [ax]+axes:
 for name in loops:
  p=loops[name];panel.fill(p[:,0],p[:,1],color='#d2d8df',edgecolor='#526171',lw=.7)
 panel.set_aspect('equal');panel.grid(alpha=.2);panel.set_xlabel('X — profundidade (mm)');panel.set_ylabel('Z — altura (mm)')
for i,s in enumerate(specs):
 color=colors[i+2];lo=s['alojamento_min'];hi=s['alojamento_max'];panel=axes[i]
 for target in [ax,panel]:
  target.add_patch(Rectangle((lo[0],lo[2]),hi[0]-lo[0],hi[2]-lo[2],fill=False,ec=color,lw=2,ls='--'))
  x0,x1=s['x']-s['w']/2,s['x']+s['w']/2;z0,z1=s['z']-s['h']/2,s['z']+s['h']/2;c=s['chanfro_mm']
  target.add_patch(Polygon([(x0+c,z0),(x1-c,z0),(x1,z0+c),(x1,z1-c),(x1-c,z1),(x0+c,z1),(x0,z1-c),(x0,z0+c)],closed=True,facecolor=color,ec='#222',lw=.6))
 ax.annotate('ABC'[i],(s['x'],s['z']),xytext=(s['x']-3,s['z']+7),arrowprops=dict(arrowstyle='->',lw=1),fontsize=13,fontweight='bold')
 panel.set_xlim(s['x']-s['w']/2-2,s['x']+s['w']/2+2);panel.set_ylim(s['z']-s['h']/2-2,s['z']+s['h']/2+2)
 panel.set_title(f"Chaveta {'ABC'[i]}: {s['length']:g} × {s['w']:g} × {s['h']:g} mm",fontsize=10)
ax.set_xlim(-70,0);ax.set_ylim(25,60);ax.set_title('Corte central Y=0: chavetas alojadas nas paredes; os vãos permanecem livres')
fig.suptitle('Emenda central — chavetas soltas e alojamentos cegos\nTracejado: alojamento com folga de 0,20 mm por face',fontsize=14);fig.savefig(O/'DETALHE_EMENDA.png',dpi=150);plt.close(fig)
print('PREVIAS E SECCAO DA EMENDA:OK',flush=True)
