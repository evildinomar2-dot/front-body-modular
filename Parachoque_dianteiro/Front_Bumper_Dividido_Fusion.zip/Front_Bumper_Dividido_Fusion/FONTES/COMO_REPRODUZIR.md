# Reprodução

Python 3.12, `cc` e bibliotecas em requirements-ambiente.txt. Execute na pasta FONTES, preferencialmente numa cópia de trabalho:

```
python preparar_base.py
python projeto.py
python exportar_cad.py
python previews.py
```

Se agrupar num shell, use `set -e` para interromper ao primeiro erro. A entrada é ../ORIGINAL/Front_Bumper_V1.stl. Os resultados da reconstrução ficam em FONTES/pacote, e os estados NPZ intermediários na própria FONTES. Eles não sobrescrevem os arquivos finais da pasta superior do ZIP. As posições e dimensões das chavetas estão em specs, no script projeto.py; as folgas estão em clearance e end_clearance. Qualquer ajuste requer nova verificação de cobertura e não invasão dos vãos.

Os scripts foram executados durante a preparação. Os caminhos relativos foram conferidos, mas a reconstrução completa desta cópia empacotada não foi repetida num ambiente novo. A parte Fusion/GerarF3D requer o Fusion no computador e foi apenas conferida sintaticamente.
