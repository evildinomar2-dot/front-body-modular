from pathlib import Path
import cadquery as cq,numpy as np,trimesh,manifold3d as md,json
from OCP.BRepTools import BRepTools
from OCP.BRepMesh import BRepMesh_IncrementalMesh
R=Path(__file__).resolve().parent;O=R/'BASE_COOPER_COBRA';O.mkdir(exist_ok=True)
source=R/'Wide_Wheel_Tire L.stl'
original=trimesh.load_mesh(source,process=True);original.apply_translation([54.3,0,0]);assert original.is_volume
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans-BoldOblique.ttf'
EMBOSS=2.0;EMBED=0.0

def mani(m):
 o=md.Manifold(md.Mesh(np.asarray(m.vertices,dtype=np.float32),np.asarray(m.faces,dtype=np.uint32)));assert str(o.status())=='Error.NoError';return o

def mesh(s):
 BRepTools.Clean_s(s.wrapped);BRepMesh_IncrementalMesh(s.wrapped,.012,False,.1,True).Perform();v,f=s.tessellate(.012,.1)
 m=trimesh.Trimesh([v.toTuple() for v in v],f,process=True)
 for d in [7,6,5]:
  if m.is_volume:break
  m.merge_vertices(digits_vertex=d);m.update_faces(m.unique_faces());m.update_faces(m.nondegenerate_faces(height=1e-10));m.remove_unreferenced_vertices()
 assert m.is_volume
 return m

def surface(xy):
 xy=np.asarray(xy);answer=np.full(len(xy),np.nan)
 for begin in range(0,len(xy),1500):
  q=xy[begin:begin+1500];origins=np.column_stack((q,np.full(len(q),10.0)));dirs=np.tile([0,0,-1],(len(q),1))
  loc,ri,_=original.ray.intersects_location(origins,dirs,multiple_hits=True)
  zz=np.full(len(q),-np.inf);np.maximum.at(zz,ri,loc[:,2]);assert np.all(np.isfinite(zz))
  answer[begin:begin+len(q)]=zz
 return answer

def glyph(ch,height):
 if ch=='FOOT':
  pts=[(-1.45,-2.5),(-.3,-2.5),(1.,-.4),(.9,.2),(1.3,.55),(2.,.55),(2.3,1.),(1.7,1.15),(2.5,1.5),(2.45,1.9),(1.5,1.9),(2.3,2.25),(2.15,2.65),(.85,2.55),(.15,1.95),(-.15,1.2),(-.9,.65),(-.35,.05),(-.7,-.6)]
  s=cq.Workplane('XY').polyline(pts).close().extrude(EMBOSS+EMBED).val()
 else:s=cq.Workplane('XY').text(ch,7,EMBOSS+EMBED,combine=False,fontPath=FONT,halign='center',valign='center').val()
 bb=s.BoundingBox();scale=height/bb.ylen
 # Scale in-plane only, retaining a total extrusion depth of 2.0 mm.
 mat=np.eye(4);mat[0,0]=mat[1,1]=scale;mat[0,3]=-(bb.xmin+bb.xmax)/2*scale;mat[1,3]=-(bb.ymin+bb.ymax)/2*scale
 s=s.transformGeometry(cq.Matrix(mat.tolist()));bb=s.BoundingBox();return s,bb.xlen

# Recess and separate inlays. The existing positive-relief files are untouched.
DEPTH=1.0;LETTER_THICKNESS=2.0;SIDE_CLEAR=.15;GLUE_GAP=.05
for d in ['STL_PNEU','LETRAS_INDIVIDUAIS','REFERENCIA','TESTE_ENCAIXE','DADOS_PREVIA']:(O/d).mkdir(exist_ok=True)

def warped(solid,bottom,height):
 refined=solid.refine_to_length(.35);mm=refined.to_mesh();v=np.array(mm.vert_properties[:,:3],float);f=np.asarray(mm.tri_verts)
 frac=(v[:,2]-v[:,2].min())/(v[:,2].max()-v[:,2].min());xy,inv=np.unique(v[:,:2],axis=0,return_inverse=True)
 h=surface(xy)[inv];v[:,2]=h+bottom+frac*height
 m=trimesh.Trimesh(v,f,process=False);assert m.is_volume
 return m,frac

def export_volume(m,path,one=True):
 m=m.copy()
 for attempt in range(3):
  assert m.is_volume,path
  if one:assert len(m.split())==1,path
  with Path(path).open('w') as stream:
   stream.write('solid pneu_letras\n')
   for normal,tri in zip(m.face_normals,m.triangles):
    stream.write('facet normal '+' '.join(format(float(v),'.17g') for v in normal)+'\nouter loop\n')
    for point in tri:stream.write('vertex '+' '.join(format(float(v),'.17g') for v in point)+'\n')
    stream.write('endloop\nendfacet\n')
   stream.write('endsolid pneu_letras\n')
  q=trimesh.load_mesh(path,process=True)
  if q.is_volume and (not one or len(q.split())==1):return
  q.merge_vertices(digits_vertex=8);q.update_faces(q.unique_faces());q.update_faces(q.nondegenerate_faces(height=1e-9));q.remove_unreferenced_vertices()
  if q.is_volume:m=q
  else:
   stable=md.Manifold(md.Mesh64(np.asarray(m.vertices,dtype=np.float64),np.asarray(m.faces,dtype=np.uint64))).simplify(1e-6*(attempt+1))
   mm=stable.to_mesh64();m=trimesh.Trimesh(mm.vert_properties[:,:3],mm.tri_verts,process=True);assert m.is_volume,(path,'precision cleanup failed')
 raise AssertionError((path,'STL roundtrip failed'))

orig=mani(original);body=orig;parts=[];records=[];cutters=[]
for word,tokens,height,radius,center_angle,gap in [('COOPER',list('COOPER'),4.8,32.,90.,1.0),('COBRA',list('COBRA'),4.2,32.,270.,1.0)]:
 gs=[glyph(ch,height) for ch in tokens];total=sum(w for _,w in gs)+gap*(len(gs)-1);cursor=-total/2
 for index,(ch,(s,width)) in enumerate(zip(tokens,gs),1):
  along=cursor+width/2;angle=center_angle-np.degrees(along/radius);phi=angle-90
  cx,cy=radius*np.cos(np.radians(angle)),radius*np.sin(np.radians(angle))
  s=s.rotate((0,0,0),(0,0,1),phi).translate((cx,cy,0));section=mani(mesh(s)).slice(1.0)
  letter,frac=warped(section.extrude(LETTER_THICKNESS),-DEPTH+GLUE_GAP,LETTER_THICKNESS)
  cutter,_=warped(section.offset(SIDE_CLEAR,md.JoinType.Round,circular_segments=32).extrude(DEPTH+1),-DEPTH,DEPTH+1)
  mc=mani(cutter);ml=mani(letter);assert (ml^orig).volume()>.2
  body=body-mc;name=f'{word}_{index:02d}_{ch}';cutters.append((name,mc,cutter))
  for oldname,oldletter,_ in parts:assert (ml^oldletter).volume()<.005,(name,oldname,'letters overlap')
  # Orient each curved back approximately tangent to the bed, without flattening its fit surface.
  to_local=trimesh.transformations.rotation_matrix(-np.radians(phi),[0,0,1]);to_local[:3,3]=to_local[:3,:3]@np.array([-cx,-cy,0])
  local=letter.copy();local.apply_transform(to_local);bpts=local.vertices[frac<1e-7]
  a,b,c=np.linalg.lstsq(np.column_stack((bpts[:,:2],np.ones(len(bpts)))),bpts[:,2],rcond=None)[0]
  normal=np.array([-a,-b,1.]);normal/=np.linalg.norm(normal);align=trimesh.geometry.align_vectors(normal,[0,0,1]);local.apply_transform(align)
  shift=np.array([2,2,0])-local.bounds[0];local.apply_translation(shift)
  export_volume(local,O/'LETRAS_INDIVIDUAIS'/(name+'_2mm.stl'))
  letter.export(O/'DADOS_PREVIA'/(name+'.ply'))
  parts.append((name,ml,letter))
  rec=dict(nome=name,palavra=word,caractere=ch,angulo_graus=angle,altura_visual_mm=height,raio_centro_mm=radius,espessura_letra_mm=LETTER_THICKNESS,profundidade_cavidade_mm=DEPTH,folga_lateral_por_face_mm=SIDE_CLEAR,folga_fundo_cola_mm=GLUE_GAP,saliencia_montada_nominal_mm=LETTER_THICKNESS-DEPTH+GLUE_GAP,matriz_impressao=(trimesh.transformations.translation_matrix(shift)@align@to_local).tolist(),dimensoes_impressao_mm=local.extents.tolist())
  records.append(rec);print('CAVIDADE E LETRA',len(records),name,flush=True);cursor+=width+gap

assert str(body.status())=='Error.NoError'
# All assembled inlays must be completely outside the remaining tire material.
for name,ml,letter in parts:
 overlap=(ml^body).volume();assert overlap<.005,(name,'interference',overlap)
for i,(name,mc,_) in enumerate(cutters):
 for oname,other,_ in cutters[:i]:assert (mc^other).volume()<.005,(name,oname,'pockets merge')
mm=body.to_mesh64();tire=trimesh.Trimesh(mm.vert_properties[:,:3],mm.tri_verts,process=True)
components=tire.split(only_watertight=False);positive=[p for p in components if p.volume>.001];assert len(positive)==1
assert all(abs(p.volume)<1e-8 and p.area<1e-8 for p in components if p is not positive[0])
tire=positive[0];assert tire.is_volume and len(tire.split())==1
print('PNEU FECHADO OK; faces de area nula removidas',len(components)-1,flush=True)
protect=md.Manifold.cylinder(60,29,29,256).translate([0,0,-45]);assert ((orig^protect)-(body^protect)).volume()<.005,'wheel seat changed'
assert (body-orig).volume()<.005
assert np.allclose(tire.bounds,original.bounds,atol=.002)
export_volume(tire,O/'REFERENCIA/Pneu_Cavidades_Montagem.stl')
printed=tire.copy();printed.apply_translation([0,0,-printed.bounds[0,2]]);export_volume(printed,O/'STL_PNEU/Pneu_COOPER_COBRA_BaixoRelevo_1mm.stl')
# One batch layout, two rows in reading order, with 2 mm between pieces.
tray=[];placements=[]
for word,rowy in [('COOPER',14),('COBRA',0)]:
 cursorx=2
 for rec in records:
  if rec['palavra']!=word:continue
  m=trimesh.load_mesh(O/'LETRAS_INDIVIDUAIS'/(rec['nome']+'_2mm.stl'));m.apply_translation([cursorx-m.bounds[0,0],rowy+2-m.bounds[0,1],0]);tray.append(m)
  placements.append(dict(nome=rec['nome'],x_min_mm=float(m.bounds[0,0]),y_min_mm=float(m.bounds[0,1])));cursorx=float(m.bounds[1,0])+2
batch=trimesh.util.concatenate(tray);export_volume(batch,O/'TODAS_AS_LETRAS_2mm.stl',False);assert len(batch.split())==len(parts)
export_volume(trimesh.util.concatenate([p for _,_,p in parts]),O/'REFERENCIA/Letras_Posicao_Montagem.stl',False)
# A small coupon with the same O pocket and the same O inlay, for an inexpensive test first.
name,mc,cutter=next(c for c in cutters if c[0]=='COOPER_02_O');letter=next(p for n,_,p in parts if n==name)
lo,hi=letter.bounds;low=np.array([lo[0]-1.5,lo[1]-1.5,-5.5]);high=np.array([hi[0]+1.5,hi[1]+1.5,5])
box=md.Manifold.cube((high-low).tolist()).translate(low.tolist());coupon=(orig-mc)^box
cm=coupon.to_mesh64();test=trimesh.Trimesh(cm.vert_properties[:,:3],cm.tri_verts,process=True);test_components=test.split(only_watertight=False);test_positive=[p for p in test_components if p.area>1e-8];assert len(test_positive)==1;test=test_positive[0]
test.apply_translation(np.array([2,2,0])-test.bounds[0]);export_volume(test,O/'TESTE_ENCAIXE/TESTE_CAVIDADE_O.stl')
import shutil
shutil.copy2(O/'LETRAS_INDIVIDUAIS'/('COOPER_02_O_2mm.stl'),O/'TESTE_ENCAIXE/TESTE_LETRA_O_2mm.stl')
# Check pocket floor depth and inlay thickness from actual export meshes.
measured=[]
for rec in records:
 letter=next(p for n,_,p in parts if n==rec['nome'])
 # Robust ray locations are selected from the original footprint surface triangles.
 top=letter.triangles_center[letter.face_normals[:,2]>.3];pts=top[::max(1,len(top)//7),:2]
 origins=np.column_stack((pts,np.full(len(pts),10.)));dirs=np.tile([0,0,-1],(len(pts),1))
 ll,li,_=tire.ray.intersects_location(origins,dirs,multiple_hits=True);zz=np.full(len(pts),-np.inf);np.maximum.at(zz,li,ll[:,2]);assert np.all(np.isfinite(zz))
 hh=surface(pts);depth=hh-zz;assert np.max(abs(depth-DEPTH))<.04,(rec['nome'],'pocket depth',depth.min(),depth.max())
 ll,li,_=letter.ray.intersects_location(origins,dirs,multiple_hits=True);topz=np.full(len(pts),-np.inf);botz=np.full(len(pts),np.inf);np.maximum.at(topz,li,ll[:,2]);np.minimum.at(botz,li,ll[:,2]);thick=topz-botz;assert np.max(abs(thick-LETTER_THICKNESS))<.04
 measured.append(dict(nome=rec['nome'],profundidade_min_mm=float(depth.min()),profundidade_max_mm=float(depth.max()),espessura_min_mm=float(thick.min()),espessura_max_mm=float(thick.max())))
report=dict(tipo='pneu_COOPER_COBRA_cavidades_e_letras_para_colar',marca='COOPER COBRA',cavidade_mm=DEPTH,letras_espessura_mm=LETTER_THICKNESS,folga_lateral_por_face_mm=SIDE_CLEAR,folga_fundo_cola_mm=GLUE_GAP,saliencia_montada_mm=LETTER_THICKNESS-DEPTH+GLUE_GAP,pneu_solidos=1,numero_letras_e_simbolo=len(parts),stl_fechados=True,assento_roda_preservado=True,dimensoes_pneu_mm=tire.extents.tolist(),dimensoes_bandeja_letras_mm=batch.extents.tolist(),sem_interpenetracao_letras_pneu=True,cavidades_sem_sobreposicao=True,teste_fisico=False,letras_curvadas=True,teste_O_incluido=True,letras=records,disposicao_bandeja=placements,medicoes=measured)
(O/'VALIDACAO.json').write_text(json.dumps(report,indent=2));print('KIT DE ENCAIXE OK',len(parts),'letras/figura',flush=True)
