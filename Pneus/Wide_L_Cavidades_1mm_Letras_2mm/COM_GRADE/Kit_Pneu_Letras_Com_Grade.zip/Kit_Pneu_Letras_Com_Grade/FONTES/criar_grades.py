from pathlib import Path
import numpy as np,trimesh,cadquery as cq,manifold3d as md,json,shutil
from OCP.BRepTools import BRepTools
from OCP.BRepMesh import BRepMesh_IncrementalMesh
R=Path(__file__).resolve().parent;BASE=R/'BASE_ENTRADA';O=R/'LETRAS_COM_GRADE';O.mkdir(exist_ok=True)
for d in ['STL_PNEU','GRADES_IMPRESSAO','REFERENCIA','CAD_ESTRUTURA','TESTE_ENCAIXE','DADOS_PREVIA']:(O/d).mkdir(exist_ok=True)
info=json.loads((BASE/'VALIDACAO.json').read_text());tire=trimesh.load_mesh(R.parent/'STL_PNEU/Pneu_Wide_L_BaixoRelevo_1mm.stl');tire.apply_translation([0,0,-37.29999923706055]);original_zmin=float(tire.bounds[0,2])
NECK_WIDTH=.8;NECK_HEIGHT=.6;FRAME_INNER=36.2;FRAME_OUTER=38.2;FRAME_BASE=1.45;FRAME_HEIGHT=1.4

def mani(m):
 o=md.Manifold(md.Mesh64(np.asarray(m.vertices,dtype=np.float64),np.asarray(m.faces,dtype=np.uint64)));assert str(o.status())=='Error.NoError';return o

def mesh(s):
 assert s.isValid()
 BRepTools.Clean_s(s.wrapped);BRepMesh_IncrementalMesh(s.wrapped,.015,False,.10,True).Perform();v,f=s.tessellate(.015,.1)
 m=trimesh.Trimesh([v.toTuple() for v in v],f,process=True);assert m.is_volume;return m

def from_mani(m):
 mm=m.to_mesh64();q=trimesh.Trimesh(mm.vert_properties[:,:3],mm.tri_verts,process=True)
 if not q.is_volume:
  real=[p for p in q.split(only_watertight=False) if p.area>1e-8];assert len(real)==1;assert real[0].is_volume;q=real[0]
 return q

def export_stl(m,path,count=1):
 m=m.copy()
 for attempt in range(3):
  assert m.is_volume
  if count:assert len(m.split())==count
  with Path(path).open('w') as stream:
   stream.write('solid letras_grade\n')
   for normal,tri in zip(m.face_normals,m.triangles):
    stream.write('facet normal '+' '.join(format(float(v),'.17g') for v in normal)+'\nouter loop\n')
    for point in tri:stream.write('vertex '+' '.join(format(float(v),'.17g') for v in point)+'\n')
    stream.write('endloop\nendfacet\n')
   stream.write('endsolid letras_grade\n')
  q=trimesh.load_mesh(path,process=True)
  if q.is_volume and (not count or len(q.split())==count):return
  q.merge_vertices(digits_vertex=8);q.update_faces(q.unique_faces());q.update_faces(q.nondegenerate_faces(height=1e-9));q.remove_unreferenced_vertices();assert q.is_volume;m=q
 raise AssertionError('STL round trip')

def frame_arc(lo,hi):
 span=hi-lo
 outer=cq.Solid.makeCylinder(FRAME_OUTER,FRAME_HEIGHT,cq.Vector(0,0,FRAME_BASE),cq.Vector(0,0,1),span)
 inner=cq.Solid.makeCylinder(FRAME_INNER,FRAME_HEIGHT+2,cq.Vector(0,0,FRAME_BASE-1),cq.Vector(0,0,1),span)
 return outer.cut(inner).rotate((0,0,0),(0,0,1),lo).clean()

def rectwire(point,er,width,height):
 et=np.array([-er[1],er[0],0.]);plane=cq.Plane(origin=cq.Vector(*point),xDir=cq.Vector(*et),normal=cq.Vector(*er));return cq.Workplane(plane).rect(width,height).val()

def print_orientation(m,letter_meshes,word):
 yaw=trimesh.transformations.rotation_matrix(np.pi if word=='EAGLE' else 0,[0,0,1])
 back=[]
 for l in letter_meshes:
  ids=np.unique(l.faces[l.face_normals[:,2]<-.3]);points=l.vertices[ids];points=trimesh.transform_points(points,yaw);back.append(points)
 points=np.concatenate(back);a,b,c=np.linalg.lstsq(np.column_stack((points[:,:2],np.ones(len(points)))),points[:,2],rcond=None)[0]
 n=np.array([-a,-b,1.]);n/=np.linalg.norm(n);rot=trimesh.geometry.align_vectors(n,[0,0,1])@yaw
 out=m.copy();out.apply_transform(rot);shift=np.array([2,2,0])-out.bounds[0];out.apply_translation(shift)
 return out,trimesh.transformations.translation_matrix(shift)@rot

body=mani(tire);words=[];records=[];contact_info=[];letters={};links={}
for rec in info['letras']:
 name=rec['nome'];m=trimesh.load_mesh(BASE/'DADOS_PREVIA'/(name+'.ply'));assert m.is_volume;letters[name]=m
 radial=np.linalg.norm(m.vertices[:,:2],axis=1);i=int(radial.argmax());xy=m.vertices[i,:2];rr=float(radial[i]);er=np.array([xy[0]/rr,xy[1]/rr,0.]);angle=float(np.degrees(np.arctan2(xy[1],xy[0]))%360)
 near=np.linalg.norm(m.vertices[:,:2]-xy,axis=1)<1e-5;top=float(m.vertices[near,2].max());h=top-info['saliencia_montada_mm']
 # One snippable side tab, below the visible top face and above the tire surface.
 p0=np.array([*xy,0.])-er*.35;p0[2]=h+.60
 plane=cq.Plane(origin=cq.Vector(*p0),xDir=cq.Vector(-er[1],er[0],0),normal=cq.Vector(*er))
 neck=cq.Workplane(plane).rect(NECK_WIDTH,NECK_HEIGHT).extrude(1.20).val()
 start=er*(rr+.65);start[2]=h+.85
 end=er*37.3;end[2]=FRAME_BASE+FRAME_HEIGHT/2
 bar=cq.Solid.makeLoft([rectwire(start,er,1.2,1.1),rectwire(end,er,1.2,1.1)],True)
 link=neck.fuse(bar).clean();assert link.isValid() and len(link.Solids())==1
 overlap=(mani(mesh(neck))^mani(m)).volume();assert overlap>.015,(name,'tab not attached',overlap)
 assert (mani(mesh(link))^body).volume()<.005,(name,'hits tire')
 links[name]=dict(shape=link,neck=neck,angle=angle,er=er,radius=rr,h=h)
 contact_info.append(dict(letra=name,angulo_ligacao_graus=angle,ponto_corte_mm=[float(xy[0]),float(xy[1]),h+.6],largura_ponta_mm=NECK_WIDTH,altura_ponta_mm=NECK_HEIGHT,sobreposicao_ponta_letra_mm3=float(overlap)))
 print('PONTA OK',name,flush=True)

for word in ['GOODYEAR','EAGLE']:
 names=[r['nome'] for r in info['letras'] if r['palavra']==word];angles=[links[n]['angle'] for n in names];lo,hi=min(angles)-6,max(angles)+6
 structure=frame_arc(lo,hi)
 for name in names:
  link=links[name]['shape']
  for other in names:
   if other!=name:assert (mani(mesh(link))^mani(letters[other])).volume()<.005,(name,other,'extra contact')
  structure=structure.fuse(link).clean()
 assert structure.isValid() and len(structure.Solids())==1,word
 structure_mesh=mesh(structure);carrier=mani(structure_mesh);assert (carrier^body).volume()<.005,(word,'frame hits tire')
 grade=carrier
 for name in names:grade=grade+mani(letters[name])
 grade_mesh=from_mani(grade);assert grade_mesh.is_volume and len(grade_mesh.split())==1,(word,'not one connected print')
 assert (grade^body).volume()<.005,(word,'assembly hits tire')
 for name in names:assert (mani(letters[name])-grade).volume()<.005
 export_stl(grade_mesh,O/'REFERENCIA'/('Grade_'+word+'_Montagem.stl'))
 grade_mesh.export(O/'DADOS_PREVIA'/('Grade_'+word+'.ply'));structure_mesh.export(O/'DADOS_PREVIA'/('Estrutura_'+word+'.ply'))
 cq.exporters.export(structure,str(O/'CAD_ESTRUTURA'/('Estrutura_'+word+'_Sem_Letras.step')))
 printed,matrix=print_orientation(grade_mesh,[letters[n] for n in names],word);export_stl(printed,O/'GRADES_IMPRESSAO'/('Grade_'+word+'_Letras_2mm.stl'))
 words.append((word,printed));records.append(dict(palavra=word,letras_e_simbolo=len(names),solidos_impressao=1,matriz_impressao=matrix.tolist(),dimensoes_impressao_mm=printed.extents.tolist(),sem_interferencia_pneu=True))
 print('GRADE OK',word,printed.extents.tolist(),flush=True)

# One file with the two independent word frames, arranged on the print bed.
layout=[];cursor=2.
for word,m in words:
 n=m.copy();n.apply_translation([2-n.bounds[0,0],cursor-n.bounds[0,1],0]);layout.append(n);cursor=float(n.bounds[1,1])+5
both=trimesh.util.concatenate(layout);assert len(both.split())==2;export_stl(both,O/'DUAS_GRADES_PARA_IMPRIMIR.stl',2)
# A single O on a small frame, matching the existing test pocket.
name='GOODYEAR_02_O';link=links[name];test_structure=frame_arc(link['angle']-5,link['angle']+5).fuse(link['shape']).clean()
test=from_mani(mani(mesh(test_structure))+mani(letters[name]));assert len(test.split())==1
p,matrix=print_orientation(test,[letters[name]],'GOODYEAR');export_stl(p,O/'TESTE_ENCAIXE/TESTE_O_COM_GRADE.stl')
shutil.copy2(R.parent/'TESTE_ENCAIXE/TESTE_CAVIDADE_O.stl',O/'TESTE_ENCAIXE/TESTE_CAVIDADE_O.stl')
shutil.copy2(R.parent/'STL_PNEU/Pneu_Wide_L_BaixoRelevo_1mm.stl',O/'STL_PNEU/Pneu_Wide_L_BaixoRelevo_1mm.stl')
report=dict(tipo='letras_em_grades_curvas_para_imprimir_e_instalar',pneu_sem_alteracao=True,cavidade_mm=info['cavidade_mm'],espessura_letras_mm=info['letras_espessura_mm'],folga_lateral_por_face_mm=info['folga_lateral_por_face_mm'],saliancia_montada_mm=info['saliencia_montada_mm'],ponta_largura_mm=NECK_WIDTH,ponta_altura_mm=NECK_HEIGHT,grade_raio_interno_mm=FRAME_INNER,grade_raio_externo_mm=FRAME_OUTER,grade_altura_mm=FRAME_HEIGHT,arquivo_duas_grades_solidos=2,dimensoes_duas_grades_impressao_mm=both.extents.tolist(),letras_posicoes_originais_preservadas=True,sem_interferencia_pneu=True,pneu_zmin_montagem_mm=original_zmin,teste_fisico=False,grades=records,pontas=contact_info)
(O/'VALIDACAO.json').write_text(json.dumps(report,indent=2));print('GRADES CONCLUIDAS',flush=True)
