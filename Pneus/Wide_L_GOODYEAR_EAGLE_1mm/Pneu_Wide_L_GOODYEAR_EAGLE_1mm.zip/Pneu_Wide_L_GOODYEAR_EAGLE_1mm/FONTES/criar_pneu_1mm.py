from pathlib import Path
import cadquery as cq,numpy as np,trimesh,manifold3d as md,json
from OCP.BRepTools import BRepTools
from OCP.BRepMesh import BRepMesh_IncrementalMesh
R=Path(__file__).resolve().parent;O=R/'ENTREGA_1MM';O.mkdir(exist_ok=True)
source=R/'Wide_Wheel_Tire L.stl'
original=trimesh.load_mesh(source,process=True);original.apply_translation([54.3,0,0]);assert original.is_volume
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans-BoldOblique.ttf'
EMBOSS=1.0;EMBED=.35

def mani(m):
 o=md.Manifold(md.Mesh(np.asarray(m.vertices,dtype=np.float32),np.asarray(m.faces,dtype=np.uint32)));assert str(o.status())=='Error.NoError';return o

def mesh(s):
 BRepTools.Clean_s(s.wrapped);BRepMesh_IncrementalMesh(s.wrapped,.012,False,.1,True).Perform();v,f=s.tessellate(.012,.1)
 m=trimesh.Trimesh([v.toTuple() for v in v],f,process=True)
 for d in [7,6,5]:
  if m.is_volume:break
  m.merge_vertices(digits_vertex=d);m.update_faces(m.unique_faces());m.update_faces(m.nondegenerate_faces(height=1e-10));m.remove_unreferenced_vertices()
 assert m.is_volume
 return m

def surface(xy):
 xy=np.asarray(xy);answer=np.full(len(xy),np.nan)
 for begin in range(0,len(xy),1500):
  q=xy[begin:begin+1500];origins=np.column_stack((q,np.full(len(q),10.0)));dirs=np.tile([0,0,-1],(len(q),1))
  loc,ri,_=original.ray.intersects_location(origins,dirs,multiple_hits=True)
  zz=np.full(len(q),-np.inf);np.maximum.at(zz,ri,loc[:,2]);assert np.all(np.isfinite(zz))
  answer[begin:begin+len(q)]=zz
 return answer

def glyph(ch,height):
 if ch=='FOOT':
  pts=[(-1.45,-2.5),(-.3,-2.5),(1.,-.4),(.9,.2),(1.3,.55),(2.,.55),(2.3,1.),(1.7,1.15),(2.5,1.5),(2.45,1.9),(1.5,1.9),(2.3,2.25),(2.15,2.65),(.85,2.55),(.15,1.95),(-.15,1.2),(-.9,.65),(-.35,.05),(-.7,-.6)]
  s=cq.Workplane('XY').polyline(pts).close().extrude(EMBOSS+EMBED).val()
 else:s=cq.Workplane('XY').text(ch,7,EMBOSS+EMBED,combine=False,fontPath=FONT,halign='center',valign='center').val()
 bb=s.BoundingBox();scale=height/bb.ylen
 # Scale in-plane only, retaining a total extrusion depth of 1.35 mm.
 mat=np.eye(4);mat[0,0]=mat[1,1]=scale;mat[0,3]=-(bb.xmin+bb.xmax)/2*scale;mat[1,3]=-(bb.ymin+bb.ymax)/2*scale
 s=s.transformGeometry(cq.Matrix(mat.tolist()));bb=s.BoundingBox();return s,bb.xlen

orig=mani(original);letter_parts=[];records=[];all_native=[]
for word,tokens,height,radius,center_angle,gap in [('GOODYEAR',['G','O','O','D','FOOT','Y','E','A','R'],4.8,32.,90.,.40),('EAGLE',list('EAGLE'),4.2,32.,270.,.65)]:
 gs=[glyph(ch,height) for ch in tokens];total=sum(w for _,w in gs)+gap*(len(gs)-1);cursor=-total/2
 for index,(ch,(s,width)) in enumerate(zip(tokens,gs),1):
  along=cursor+width/2;angle=center_angle-np.degrees(along/radius);phi=angle-90
  s=s.rotate((0,0,0),(0,0,1),phi).translate((radius*np.cos(np.radians(angle)),radius*np.sin(np.radians(angle)),0))
  base=mani(mesh(s)).refine_to_length(.50);mm=base.to_mesh();v=np.array(mm.vert_properties[:,:3],float);f=np.asarray(mm.tri_verts)
  # Exact projection to the supplied sidewall, then 1 mm axial relief above it.
  xy,inv=np.unique(v[:,:2],axis=0,return_inverse=True);h=surface(xy)[inv]
  fraction=(v[:,2]-v[:,2].min())/(v[:,2].max()-v[:,2].min());v[:,2]=h-EMBED+fraction*(EMBOSS+EMBED)
  part=trimesh.Trimesh(v,f,process=True);assert part.is_volume
  relief=mani(part);overlap=(relief^orig).volume();assert overlap>.2,(ch,'not attached',overlap)
  name=f'{word}_{index:02d}_{ch}';part.export(O/(name+'.ply'));letter_parts.append((name,part,relief));all_native.append((name,s))
  rr=np.linalg.norm(v[:,:2],axis=1);assert rr.min()>29 and rr.max()<35,(ch,rr.min(),rr.max())
  # On upward-facing text facets, compare the actual refined top with the input surface.
  topmask=(part.face_normals[:,2]>.3);centers=part.triangles_center[topmask];centers=centers[::max(1,len(centers)//25)]
  hh=surface(centers[:,:2]);excess=centers[:,2]-hh
  assert np.max(np.abs(excess-EMBOSS))<.05,(ch,'height deviation',excess.min(),excess.max())
  records.append(dict(nome=name,caractere=ch,palavra=word,angulo_graus=angle,altura_letra_mm=height,raio_centro_mm=radius,raio_min_mm=float(rr.min()),raio_max_mm=float(rr.max()),sobreposicao_substrato_mm3=float(overlap),relevo_medido_min_mm=float(excess.min()),relevo_medido_max_mm=float(excess.max())))
  print('LETRA OK',name,len(v),'vertices','relevo',round(excess.min(),4),round(excess.max(),4),flush=True);cursor+=width+gap
# Unite all letters with the supplied tire; no subtraction or rescaling of the input.
result=orig
for _,_,letter in letter_parts:result=result+letter
assert str(result.status())=='Error.NoError'
mm=result.to_mesh();final=trimesh.Trimesh(mm.vert_properties[:,:3],mm.tri_verts,process=True)
assert final.is_volume and len(final.split())==1
assert (orig-result).volume()<.005,'original tire changed'
# A protected cylinder covers the wheel bead/seat: additions may not enter it.
protect=md.Manifold.cylinder(60,29,29,256).translate([0,0,-45])
assert ((result^protect)-(orig^protect)).volume()<.005,'wheel seat changed'
assert np.allclose(final.bounds[:,:2],original.bounds[:,:2],atol=.002)
final.export(O/'Pneu_GOODYEAR_EAGLE_Montagem.stl')
printed=final.copy();printed.apply_translation([0,0,-printed.bounds[0,2]]);printed.export(O/'Pneu_GOODYEAR_EAGLE_Impressao.stl')
for f in ['Pneu_GOODYEAR_EAGLE_Montagem.stl','Pneu_GOODYEAR_EAGLE_Impressao.stl']:
 test=trimesh.load_mesh(O/f);assert test.is_volume and len(test.split())==1
# Optional text-only mesh for painting/multi-material reference, already curved and located.
letters=trimesh.util.concatenate([p for _,p,_ in letter_parts]);letters.export(O/'Letras_Referencia_Montagem.stl')
report=dict(tipo='pneu_original_com_relevo_axial',texto_superior='GOODYEAR',texto_inferior='EAGLE',simbolo_estilizado=True,relevo_axial_mm=EMBOSS,ancoragem_no_pneu_mm=EMBED,lateral='frente_Z_positivo',numero_laterais_modificadas=1,dimensoes_originais_mm=original.extents.tolist(),dimensoes_finais_mm=final.extents.tolist(),volume_original_mm3=float(original.volume),volume_final_mm3=float(final.volume),original_preservado=True,assento_roda_preservado=True,stl_fechado=True,solidos_stl=1,teste_fisico=False,fonte='DejaVu Sans Bold Oblique',largura_letra_ou_simbolo_variavel=True,letras=records)
(O/'VALIDACAO.json').write_text(json.dumps(report,indent=2));print('PNEU FINAL OK',len(final.faces),'faces',flush=True)
